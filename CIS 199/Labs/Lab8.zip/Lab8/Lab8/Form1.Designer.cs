﻿namespace Lab8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WPMLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.noOfYearBox = new System.Windows.Forms.TextBox();
            this.annualIntRateBox = new System.Windows.Forms.TextBox();
            this.FVBox = new System.Windows.Forms.TextBox();
            this.calculatedLbl = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WPMLbl
            // 
            this.WPMLbl.AutoSize = true;
            this.WPMLbl.Location = new System.Drawing.Point(12, 118);
            this.WPMLbl.Name = "WPMLbl";
            this.WPMLbl.Size = new System.Drawing.Size(101, 17);
            this.WPMLbl.TabIndex = 9;
            this.WPMLbl.Text = "Present Value:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "No. of Year:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Annual Interest Rate:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Future Value:";
            // 
            // noOfYearBox
            // 
            this.noOfYearBox.Location = new System.Drawing.Point(153, 82);
            this.noOfYearBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.noOfYearBox.Name = "noOfYearBox";
            this.noOfYearBox.Size = new System.Drawing.Size(89, 22);
            this.noOfYearBox.TabIndex = 13;
            // 
            // annualIntRateBox
            // 
            this.annualIntRateBox.Location = new System.Drawing.Point(153, 42);
            this.annualIntRateBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.annualIntRateBox.Name = "annualIntRateBox";
            this.annualIntRateBox.Size = new System.Drawing.Size(89, 22);
            this.annualIntRateBox.TabIndex = 14;
            // 
            // FVBox
            // 
            this.FVBox.Location = new System.Drawing.Point(153, 6);
            this.FVBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FVBox.Name = "FVBox";
            this.FVBox.Size = new System.Drawing.Size(89, 22);
            this.FVBox.TabIndex = 15;
            // 
            // calculatedLbl
            // 
            this.calculatedLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calculatedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculatedLbl.Location = new System.Drawing.Point(153, 118);
            this.calculatedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.calculatedLbl.Name = "calculatedLbl";
            this.calculatedLbl.Size = new System.Drawing.Size(89, 26);
            this.calculatedLbl.TabIndex = 16;
            this.calculatedLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(75, 161);
            this.calcButton.Margin = new System.Windows.Forms.Padding(4);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(102, 33);
            this.calcButton.TabIndex = 17;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(260, 209);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.calculatedLbl);
            this.Controls.Add(this.FVBox);
            this.Controls.Add(this.annualIntRateBox);
            this.Controls.Add(this.noOfYearBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.WPMLbl);
            this.Name = "Form1";
            this.Text = "Lab8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WPMLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox noOfYearBox;
        private System.Windows.Forms.TextBox annualIntRateBox;
        private System.Windows.Forms.TextBox FVBox;
        private System.Windows.Forms.Label calculatedLbl;
        private System.Windows.Forms.Button calcButton;
    }
}


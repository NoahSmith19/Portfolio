﻿// Lab 8
// CIS 199-01
// Due: 3/31/2019
// M7874

// This form calculates present value but uses a method for the math

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class Form1 : Form
    {
        double futureValue;
        double annualIntRate;
        double noOfYear;
        double calculation;

        public Form1()
        {
            InitializeComponent();
        }

        // user has clicked the calcButton
        // will read user input and calculate present value
        private void calcButton_Click(object sender, EventArgs e)
        {
            

            if (double.TryParse(FVBox.Text, out futureValue))                       // if the TryParse works do the following...
            {
                if (double.TryParse(annualIntRateBox.Text, out annualIntRate))      // if the TryParse works do the following...
                {
                    if (double.TryParse(noOfYearBox.Text, out noOfYear))            // if the TryParse works do the following...
                    {
                        Lab8Method();                                               // this runs the named method before continuing
                        calculatedLbl.Text = $"{calculation}";                      // displays the calculated output

                    }
                    else                                                           // otherwise do the following
                    {
                        MessageBox.Show("Enter a valid year");                     // if the TryParse doesnt work for enterTestScoreBox then output "Enter a valid GPA"
                    }
                }
                else                                                               // otherwise do the following
                {
                    MessageBox.Show("Enter a valid rate");                         // if the TryParse doesnt work for enterTestScoreBox then output "Enter a valid GPA"
                }
            }
            else                                                                   // otherwise do the following
            {
                MessageBox.Show("Enter a valid future value");                     // if the TryParse doesnt work for enterTestScoreBox then output "Enter a valid GPA"
            }
        }

        // the method is named Lab8Method
        // this method does the calculation for present value
        private void Lab8Method()
        {
            calculation = (futureValue) / (Math.Pow(1 + annualIntRate, noOfYear));
        }
    }
}

﻿// Grading ID:      M7874
// Lab Number:      Lab 4
// Due Date:        2/17/19
// Course Section:  199-01
//Discription:      This form decides if someone is accepted based on their GPA and test score and then tallys the results.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {

        private int numAccepted = 0,       // declares numAccepted for the whole document
            numRejected = 0;               // declares numRejected for the whole document

        public Form1()
        {
            InitializeComponent();
        }

        // this is the form created
        private void calcButton_Click(object sender, EventArgs e)
        {
            double neededGPA = 3.0,        // declared variable for neededGPA
                lowScore = 60,             // declared variable for lowScore
                highScore = 80,            // declared variable for highScore
                GPA,                       // declares GPA as double for the button
                TEST_SCORE;                // declares TEST_SCORE as double for the button


            if (double.TryParse(enterGPABox.Text, out GPA))                                           // if you can parse output GPA
            {
                if (double.TryParse(enterTestScoreBox.Text, out TEST_SCORE))                          // if you can parse output TEST_SCORE
                {
                    if ((GPA >= neededGPA && TEST_SCORE >= lowScore) || (GPA < neededGPA && TEST_SCORE >= highScore))          // arguments to be followed to decide if acccepted or rejected
                    {
                        calculatedBox.Text = "Accepted";                                              // if calculatedBox.Text is accepted
                        numAccepted = numAccepted + 1;                                                // then add one to numAccepted
                        acceptedOutLbl.Text = $"{numAccepted}";                                       // and output that value in acceptedOutLbl
                    }
                    else                                                                              // otherwise do the following
                    {
                        calculatedBox.Text = "Rejected";                                              // if calculatedBox.Text is rejected
                        numRejected = numRejected + 1;                                                // then add one to numRejected
                        rejectedOutLbl.Text = $"{numRejected}";                                       //and output that value in rejectedOutLbl
                    }
                }
                else                                                                                  // otherwise do the following
                {
                    MessageBox.Show("Enter a valid test score");                                      // if the TryParse for enterGPABox doesn't work then output "Enter a valid test score"
                }
            }
            else                                                                                      // otherwise do the following
            {
                MessageBox.Show("Enter a valid GPA");                                                 // if the TryParse doesnt work for enterTestScoreBox then output "Enter a valid GPA"

            }

            
        }
    }
}

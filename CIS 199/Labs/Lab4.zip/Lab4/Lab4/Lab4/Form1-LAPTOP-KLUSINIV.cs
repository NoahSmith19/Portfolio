﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {

        private int numAccepted = 0,
            numRejected = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            double GPA,
                TEST_SCORE;


            if (double.TryParse(enterGPABox.Text, out GPA))
            {
                if (double.TryParse(enterTestScoreBox.Text, out TEST_SCORE))
                {
                    if ((GPA >= 3.0 && TEST_SCORE >= 60) || (GPA < 3.0 && TEST_SCORE >= 80))
                    {
                        calculatedBox.Text = "Accepted";
                        numAccepted = numAccepted + 1;
                        acceptedOutLbl.Text = $"{numAccepted}";
                    }
                    else
                    {
                        calculatedBox.Text = "Rejected";
                        numRejected = numRejected + 1;
                        rejectedOutLbl.Text = $"{numRejected}";
                    }
                }
                else
                {
                    MessageBox.Show("Enter a valid test score");
                }
            }
            else
            {
                MessageBox.Show("Enter a valid GPA");

            }

            
        }
    }
}

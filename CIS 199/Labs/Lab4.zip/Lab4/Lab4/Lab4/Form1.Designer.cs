﻿namespace Lab4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterGPABox = new System.Windows.Forms.TextBox();
            this.enterTestScoreBox = new System.Windows.Forms.TextBox();
            this.GPALbl = new System.Windows.Forms.Label();
            this.testScoreLbl = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.calculatedBox = new System.Windows.Forms.Label();
            this.RejectedLbl = new System.Windows.Forms.Label();
            this.acceptedLbl = new System.Windows.Forms.Label();
            this.acceptedOutLbl = new System.Windows.Forms.Label();
            this.rejectedOutLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // enterGPABox
            // 
            this.enterGPABox.Location = new System.Drawing.Point(77, 18);
            this.enterGPABox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.enterGPABox.Name = "enterGPABox";
            this.enterGPABox.Size = new System.Drawing.Size(68, 20);
            this.enterGPABox.TabIndex = 5;
            // 
            // enterTestScoreBox
            // 
            this.enterTestScoreBox.Location = new System.Drawing.Point(77, 52);
            this.enterTestScoreBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.enterTestScoreBox.Name = "enterTestScoreBox";
            this.enterTestScoreBox.Size = new System.Drawing.Size(68, 20);
            this.enterTestScoreBox.TabIndex = 6;
            // 
            // GPALbl
            // 
            this.GPALbl.AutoSize = true;
            this.GPALbl.Location = new System.Drawing.Point(41, 21);
            this.GPALbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.GPALbl.Name = "GPALbl";
            this.GPALbl.Size = new System.Drawing.Size(32, 13);
            this.GPALbl.TabIndex = 7;
            this.GPALbl.Text = "GPA:";
            // 
            // testScoreLbl
            // 
            this.testScoreLbl.AutoSize = true;
            this.testScoreLbl.Location = new System.Drawing.Point(11, 52);
            this.testScoreLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.testScoreLbl.Name = "testScoreLbl";
            this.testScoreLbl.Size = new System.Drawing.Size(62, 13);
            this.testScoreLbl.TabIndex = 8;
            this.testScoreLbl.Text = "Test Score:";
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(53, 95);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 9;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // calculatedBox
            // 
            this.calculatedBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calculatedBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculatedBox.Location = new System.Drawing.Point(53, 144);
            this.calculatedBox.Name = "calculatedBox";
            this.calculatedBox.Size = new System.Drawing.Size(75, 21);
            this.calculatedBox.TabIndex = 12;
            this.calculatedBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RejectedLbl
            // 
            this.RejectedLbl.AutoSize = true;
            this.RejectedLbl.Location = new System.Drawing.Point(253, 59);
            this.RejectedLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.RejectedLbl.Name = "RejectedLbl";
            this.RejectedLbl.Size = new System.Drawing.Size(53, 13);
            this.RejectedLbl.TabIndex = 13;
            this.RejectedLbl.Text = "Rejected:";
            // 
            // acceptedLbl
            // 
            this.acceptedLbl.AutoSize = true;
            this.acceptedLbl.Location = new System.Drawing.Point(253, 25);
            this.acceptedLbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.acceptedLbl.Name = "acceptedLbl";
            this.acceptedLbl.Size = new System.Drawing.Size(56, 13);
            this.acceptedLbl.TabIndex = 14;
            this.acceptedLbl.Text = "Accepted:";
            // 
            // acceptedOutLbl
            // 
            this.acceptedOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptedOutLbl.Location = new System.Drawing.Point(311, 20);
            this.acceptedOutLbl.Name = "acceptedOutLbl";
            this.acceptedOutLbl.Size = new System.Drawing.Size(81, 21);
            this.acceptedOutLbl.TabIndex = 15;
            // 
            // rejectedOutLbl
            // 
            this.rejectedOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejectedOutLbl.Location = new System.Drawing.Point(311, 51);
            this.rejectedOutLbl.Name = "rejectedOutLbl";
            this.rejectedOutLbl.Size = new System.Drawing.Size(81, 21);
            this.rejectedOutLbl.TabIndex = 16;
            // 
            // Form1
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.rejectedOutLbl);
            this.Controls.Add(this.acceptedOutLbl);
            this.Controls.Add(this.acceptedLbl);
            this.Controls.Add(this.RejectedLbl);
            this.Controls.Add(this.calculatedBox);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.testScoreLbl);
            this.Controls.Add(this.GPALbl);
            this.Controls.Add(this.enterTestScoreBox);
            this.Controls.Add(this.enterGPABox);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox enterGPABox;
        private System.Windows.Forms.TextBox enterTestScoreBox;
        private System.Windows.Forms.Label GPALbl;
        private System.Windows.Forms.Label testScoreLbl;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label calculatedBox;
        private System.Windows.Forms.Label RejectedLbl;
        private System.Windows.Forms.Label acceptedLbl;
        private System.Windows.Forms.Label acceptedOutLbl;
        private System.Windows.Forms.Label rejectedOutLbl;
    }
}


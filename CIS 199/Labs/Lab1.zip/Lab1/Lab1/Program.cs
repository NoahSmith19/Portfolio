﻿//Grading ID: M7874
// Lab Number: Lab 1
// Due Date: January, 20th 2019
//Course Section: CIS 199-01
//Discription: This program displays some information about me
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grading ID:     M7874");
            Console.WriteLine("Hobbies:        Cycling and Beekeeping");
            Console.WriteLine("Favorite Book:  Grant");
            Console.WriteLine("Favorite Movie: The Shawshank Redemption");
            
        }
    }
}

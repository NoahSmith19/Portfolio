﻿// Grading ID:      M7874
// Lab Number:      Lab 3
// Due Date:        2/10/19
// Course Section:  199-01
//Discription:      This form calculates Diameter, Area, and Volume of a sphere given its radius.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcRadiusbutton_Click(object sender, EventArgs e)  // this is when the user clicks the button
        {
            double RADIUS, DIAMETER, AREA, VOLUME;                       // converts the declared variables to double
            const double PIE = 3.14159;                                  // created a constant for pi

            RADIUS = double.Parse(enterRadiusBox.Text);                  // converts the declared text box to double
            DIAMETER = 2 * RADIUS;                                       // math for diameter
            AREA = 4 * PIE * (RADIUS * RADIUS);                          // math for area
            VOLUME = (4 * PIE * (RADIUS * RADIUS * RADIUS)) / 3;         // math for volume

            diameterLbl.Text = $"{DIAMETER:N2}";                         // puts the DIAMETER variable in diameterLbl and converts it to number with 2 decimal places
            areaLbl.Text = $"{AREA:N2}";                                 // puts the AREA variable in arearLbl and converts it to number with 2 decimal places
            volumeLbl.Text = $"{VOLUME:N2}";                             // puts the VOLUME variable in volumeLbl and converts it to number with 2 decimal places

        }
    }
}

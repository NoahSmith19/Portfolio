﻿namespace Lab3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.enterRadiusBox = new System.Windows.Forms.TextBox();
            this.calcRadiusbutton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.diameterLbl = new System.Windows.Forms.Label();
            this.areaLbl = new System.Windows.Forms.Label();
            this.volumeLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Radius of sphere:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 117);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Diameter";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 148);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Surface Area";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 176);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Volume";
            // 
            // enterRadiusBox
            // 
            this.enterRadiusBox.Location = new System.Drawing.Point(177, 13);
            this.enterRadiusBox.Margin = new System.Windows.Forms.Padding(2);
            this.enterRadiusBox.Name = "enterRadiusBox";
            this.enterRadiusBox.Size = new System.Drawing.Size(68, 20);
            this.enterRadiusBox.TabIndex = 4;
            // 
            // calcRadiusbutton
            // 
            this.calcRadiusbutton.Location = new System.Drawing.Point(181, 47);
            this.calcRadiusbutton.Margin = new System.Windows.Forms.Padding(2);
            this.calcRadiusbutton.Name = "calcRadiusbutton";
            this.calcRadiusbutton.Size = new System.Drawing.Size(59, 22);
            this.calcRadiusbutton.TabIndex = 5;
            this.calcRadiusbutton.Text = "Calculate";
            this.calcRadiusbutton.UseVisualStyleBackColor = true;
            this.calcRadiusbutton.Click += new System.EventHandler(this.calcRadiusbutton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Lab3.Properties.Resources.Sphere_and_Ball;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 102);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Lab3.Properties.Resources.Sphere_and_Ball;
            this.pictureBox2.Location = new System.Drawing.Point(161, 110);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(79, 102);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // diameterLbl
            // 
            this.diameterLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.diameterLbl.Location = new System.Drawing.Point(75, 116);
            this.diameterLbl.Name = "diameterLbl";
            this.diameterLbl.Size = new System.Drawing.Size(81, 21);
            this.diameterLbl.TabIndex = 11;
            // 
            // areaLbl
            // 
            this.areaLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.areaLbl.Location = new System.Drawing.Point(75, 147);
            this.areaLbl.Name = "areaLbl";
            this.areaLbl.Size = new System.Drawing.Size(81, 21);
            this.areaLbl.TabIndex = 12;
            // 
            // volumeLbl
            // 
            this.volumeLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.volumeLbl.Location = new System.Drawing.Point(75, 175);
            this.volumeLbl.Name = "volumeLbl";
            this.volumeLbl.Size = new System.Drawing.Size(81, 21);
            this.volumeLbl.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(252, 224);
            this.Controls.Add(this.volumeLbl);
            this.Controls.Add(this.areaLbl);
            this.Controls.Add(this.diameterLbl);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.calcRadiusbutton);
            this.Controls.Add(this.enterRadiusBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Lab3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox enterRadiusBox;
        private System.Windows.Forms.Button calcRadiusbutton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label diameterLbl;
        private System.Windows.Forms.Label areaLbl;
        private System.Windows.Forms.Label volumeLbl;
    }
}


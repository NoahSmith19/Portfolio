﻿// Grading ID:      M7874
// Lab Number:      Lab 2
// Due Date:        2/4/19
// Course Section:  199-01
//Discription:      This form calculates a tip in 15%, 18%, and 20% based on the amount entered.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcTipbutton_Click(object sender, EventArgs e) // this is when the user clicks the button
        {
            double PRICE, FIFTEEN, EIGHTEEN, TWENTY;   // converts the declared variables to double
            const double TIP15 = .15, TIP18 = .18, TIP20 = .20;  // created a constant for the tip percentages

            PRICE = double.Parse(enterPriceBox.Text);  // converts the declared text box to double
            FIFTEEN = PRICE * TIP15;                     // math for 15%
            EIGHTEEN = PRICE * TIP18;                    // math for 18%
            TWENTY = PRICE * TIP20;                      // math for 20%

            tip15label.Text = $"{FIFTEEN:C2}";         // puts the FIFTEEN variable in tip15label and converts it to currency
            tip18label.Text = $"{EIGHTEEN:C2}";        // puts the EIGHTEEN variable in tip18label and converts it to currency
            tip20label.Text = $"{TWENTY:C2}";          // puts the TWENTY variable in tip20label and converts it to currency
        }
    }
}

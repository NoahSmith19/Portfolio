﻿// Lab 6
// CIS 199-XX
// Due: 3/10/2019
// By: Andrew L. Wright (Students use Grading ID)

// File: Program.cs
// This file demonstrates the use of nested loops to produce
// 4 sets of patterns made up of asterisks.

// Remember, you need to use CTRL-F5 to run Console application

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

class Program
{
    // Console application always starts in Main method
    // Displays patterns created with nested loops
    static void Main(string[] args)
    {
        const int MAX_ROWS = 10; // Number of rows/stars per row in each pattern

        // "\n" produces a new line in the output
        WriteLine("Pattern A\n");

        for (int row = 1; row <= MAX_ROWS; row++) // row is also # of stars on line
        {
            for (int star = 1; star <= row; star++)
                Write("*");

            WriteLine();
        }

        WriteLine("\nPattern B\n");

        for (int row = MAX_ROWS; row >= 1; row--) // row is also # of stars on line
        {
            for (int star = 1; star <= row; star++)
                Write("*");

            WriteLine();
        }

        WriteLine("\nPattern C\n");

        for (int row = MAX_ROWS; row >= 1; row--) // row is also # of stars on line
        {
            // Need (MAX_ROWS - row) # of spaces first
            for (int space = 1; space <= (MAX_ROWS - row); space++)
                Write(" ");

            for (int star = 1; star <= row; star++)
                Write("*");

            WriteLine();
        }

        WriteLine("\nPattern D\n");

        for (int row = 1; row <= MAX_ROWS; row++) // row is also # of stars on line
        {
            // Need (MAX_ROWS - row) # of spaces first
            for (int space = 1; space <= (MAX_ROWS - row); space++)
                Write(" ");

            for (int star = 1; star <= row; star++)
                Write("*");

            WriteLine();
        }
    }
}
﻿// Lab 9
// CIS 199-01
// Due: 4/21/2019
// M7874

// This form displays a dite with the given info

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class Form1 : Form
    {
        private Date Date; //Date used in form
        public Form1()
        {
            InitializeComponent();

            Date = new Date(1, 1, 2000); //Init forms date
            dateInput.Text = Date.ToString(); //Set input to date
        }

        //Update date based on button click

        private void MonthBtn_Click(object sender, EventArgs e)
        {
            updateDate(monthInput.Text, Date.DateProperties.Month);
        }

        //Update date based on button click

        private void DayBtn_Click(object sender, EventArgs e)
        {
            updateDate(dayInput.Text, Date.DateProperties.Day);
        }

        //Update date based on button click

        private void YearBtn_Click(object sender, EventArgs e)
        {
            updateDate(yearInput.Text, Date.DateProperties.Year);
        }

        /// Change the selected date properties based on input
        /// PreCondition: Must pass string and which date property you want to change
        /// PostCondition: Displays error is unable to parse or sets value

        private void updateDate(string text, Date.DateProperties type)
        {
            int value; //Value of the parse

            if (int.TryParse(text, out value)) //Parse input
            {
                //Switch by property and set value
                switch (type)
                {
                    case Date.DateProperties.Month:
                        Date.Month = value;
                        break;
                    case Date.DateProperties.Day:
                        Date.Day = value;
                        break;
                    case Date.DateProperties.Year:
                        Date.Year = value;
                        break;
                }

                //Reset date input in GUI
                dateInput.Text = Date.ToString();
            }
            else
            {
                //Display error if can't parse
                MessageBox.Show("Please check " + type.ToString() + " entry");
            }
        }
    }
}

﻿namespace Lab9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DateLbl = new System.Windows.Forms.Label();
            this.YearLbl = new System.Windows.Forms.Label();
            this.DayLbl = new System.Windows.Forms.Label();
            this.MonthLbl = new System.Windows.Forms.Label();
            this.dateInput = new System.Windows.Forms.Label();
            this.monthInput = new System.Windows.Forms.TextBox();
            this.dayInput = new System.Windows.Forms.TextBox();
            this.yearInput = new System.Windows.Forms.TextBox();
            this.DayBtn = new System.Windows.Forms.Button();
            this.MonthBtn = new System.Windows.Forms.Button();
            this.YearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DateLbl
            // 
            this.DateLbl.AutoSize = true;
            this.DateLbl.Location = new System.Drawing.Point(61, 23);
            this.DateLbl.Name = "DateLbl";
            this.DateLbl.Size = new System.Drawing.Size(42, 17);
            this.DateLbl.TabIndex = 10;
            this.DateLbl.Text = "Date:";
            // 
            // YearLbl
            // 
            this.YearLbl.AutoSize = true;
            this.YearLbl.Location = new System.Drawing.Point(38, 149);
            this.YearLbl.Name = "YearLbl";
            this.YearLbl.Size = new System.Drawing.Size(42, 17);
            this.YearLbl.TabIndex = 11;
            this.YearLbl.Text = "Year:";
            // 
            // DayLbl
            // 
            this.DayLbl.AutoSize = true;
            this.DayLbl.Location = new System.Drawing.Point(43, 106);
            this.DayLbl.Name = "DayLbl";
            this.DayLbl.Size = new System.Drawing.Size(37, 17);
            this.DayLbl.TabIndex = 12;
            this.DayLbl.Text = "Day:";
            // 
            // MonthLbl
            // 
            this.MonthLbl.AutoSize = true;
            this.MonthLbl.Location = new System.Drawing.Point(29, 66);
            this.MonthLbl.Name = "MonthLbl";
            this.MonthLbl.Size = new System.Drawing.Size(51, 17);
            this.MonthLbl.TabIndex = 13;
            this.MonthLbl.Text = "Month:";
            // 
            // dateInput
            // 
            this.dateInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateInput.Location = new System.Drawing.Point(110, 17);
            this.dateInput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dateInput.Name = "dateInput";
            this.dateInput.Size = new System.Drawing.Size(129, 26);
            this.dateInput.TabIndex = 17;
            this.dateInput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // monthInput
            // 
            this.monthInput.Location = new System.Drawing.Point(86, 63);
            this.monthInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.monthInput.Name = "monthInput";
            this.monthInput.Size = new System.Drawing.Size(89, 22);
            this.monthInput.TabIndex = 18;
            // 
            // dayInput
            // 
            this.dayInput.Location = new System.Drawing.Point(86, 103);
            this.dayInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dayInput.Name = "dayInput";
            this.dayInput.Size = new System.Drawing.Size(89, 22);
            this.dayInput.TabIndex = 19;
            // 
            // yearInput
            // 
            this.yearInput.Location = new System.Drawing.Point(86, 144);
            this.yearInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.yearInput.Name = "yearInput";
            this.yearInput.Size = new System.Drawing.Size(89, 22);
            this.yearInput.TabIndex = 20;
            // 
            // DayBtn
            // 
            this.DayBtn.Location = new System.Drawing.Point(182, 98);
            this.DayBtn.Margin = new System.Windows.Forms.Padding(4);
            this.DayBtn.Name = "DayBtn";
            this.DayBtn.Size = new System.Drawing.Size(129, 33);
            this.DayBtn.TabIndex = 21;
            this.DayBtn.Text = "Update Day";
            this.DayBtn.UseVisualStyleBackColor = true;
            this.DayBtn.Click += new System.EventHandler(this.DayBtn_Click);
            // 
            // MonthBtn
            // 
            this.MonthBtn.Location = new System.Drawing.Point(182, 58);
            this.MonthBtn.Margin = new System.Windows.Forms.Padding(4);
            this.MonthBtn.Name = "MonthBtn";
            this.MonthBtn.Size = new System.Drawing.Size(129, 32);
            this.MonthBtn.TabIndex = 22;
            this.MonthBtn.Text = "Update Month";
            this.MonthBtn.UseVisualStyleBackColor = true;
            this.MonthBtn.Click += new System.EventHandler(this.MonthBtn_Click);
            // 
            // YearBtn
            // 
            this.YearBtn.Location = new System.Drawing.Point(182, 139);
            this.YearBtn.Margin = new System.Windows.Forms.Padding(4);
            this.YearBtn.Name = "YearBtn";
            this.YearBtn.Size = new System.Drawing.Size(129, 33);
            this.YearBtn.TabIndex = 23;
            this.YearBtn.Text = "Update Year";
            this.YearBtn.UseVisualStyleBackColor = true;
            this.YearBtn.Click += new System.EventHandler(this.YearBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 224);
            this.Controls.Add(this.YearBtn);
            this.Controls.Add(this.MonthBtn);
            this.Controls.Add(this.DayBtn);
            this.Controls.Add(this.yearInput);
            this.Controls.Add(this.dayInput);
            this.Controls.Add(this.monthInput);
            this.Controls.Add(this.dateInput);
            this.Controls.Add(this.MonthLbl);
            this.Controls.Add(this.DayLbl);
            this.Controls.Add(this.YearLbl);
            this.Controls.Add(this.DateLbl);
            this.Name = "Form1";
            this.Text = "Lab 9";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label DateLbl;
        private System.Windows.Forms.Label YearLbl;
        private System.Windows.Forms.Label DayLbl;
        private System.Windows.Forms.Label MonthLbl;
        private System.Windows.Forms.Label dateInput;
        private System.Windows.Forms.TextBox monthInput;
        private System.Windows.Forms.TextBox dayInput;
        private System.Windows.Forms.TextBox yearInput;
        private System.Windows.Forms.Button DayBtn;
        private System.Windows.Forms.Button MonthBtn;
        private System.Windows.Forms.Button YearBtn;
    }
}


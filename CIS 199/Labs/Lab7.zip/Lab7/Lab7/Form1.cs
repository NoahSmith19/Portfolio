﻿// Grading ID:      M7874
// Lab Number:      Lab 7
// Due Date:        3/24/19
// Course Section:  199-01
//Discription:      This form takes a users words per minute and outputs their grade

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace Lab7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // clicking run starts this section of code
        private void calcButton_Click(object sender, EventArgs e)
        {
            int[] range = { 100, 75, 50, 30, 15 };                     // waximum wpm per grade
            string[] letterGrade = { "A", "B", "C", "D", "F" };        // letter grades available
            int wpm;                                                   // declares int for spm
            bool isInRange = false;                                    // declares isInRange as bool at sets the value to false
            string grade = string.Empty;                               // declares grade as a empty string

            if (int.TryParse(WPMBox.Text, out wpm))                    // TryParses the WPMBox
            {

                int index = range.Length - 1;                          // sets the int index as range - 1

                while (index >= 0 && !isInRange)                       // if the entered ammount is within the range do the following
                {
                    if (wpm <= range[index])                           // if WPM is lower than the value
                    {
                        isInRange = true;                              // change isInRange to true
                    }
                    else                                               // next value in the array
                    {
                        --index;
                    }
                }
                if (isInRange)                                         // if isInRange is true
                {
                    grade = letterGrade[index];                        // stores letterGrade array value to grade string
                }
                calculatedLbl.Text = grade;                            // displays grade to user
            }
            else                                                       // otherwise do the following
            {
                MessageBox.Show("Enter a valid GPA");                  // if the TryParse doesnt work for enterTestScoreBox then output "Enter a valid GPA"

            }
        }
    }
}

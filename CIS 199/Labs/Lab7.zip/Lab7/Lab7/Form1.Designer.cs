﻿namespace Lab7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WPMLbl = new System.Windows.Forms.Label();
            this.WPMBox = new System.Windows.Forms.TextBox();
            this.calculatedLbl = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WPMLbl
            // 
            this.WPMLbl.AutoSize = true;
            this.WPMLbl.Location = new System.Drawing.Point(12, 34);
            this.WPMLbl.Name = "WPMLbl";
            this.WPMLbl.Size = new System.Drawing.Size(125, 17);
            this.WPMLbl.TabIndex = 8;
            this.WPMLbl.Text = "Words Per Minute:";
            // 
            // WPMBox
            // 
            this.WPMBox.Location = new System.Drawing.Point(143, 34);
            this.WPMBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.WPMBox.Name = "WPMBox";
            this.WPMBox.Size = new System.Drawing.Size(89, 22);
            this.WPMBox.TabIndex = 9;
            // 
            // calculatedLbl
            // 
            this.calculatedLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calculatedLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculatedLbl.Location = new System.Drawing.Point(74, 142);
            this.calculatedLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.calculatedLbl.Name = "calculatedLbl";
            this.calculatedLbl.Size = new System.Drawing.Size(99, 25);
            this.calculatedLbl.TabIndex = 14;
            this.calculatedLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(74, 80);
            this.calcButton.Margin = new System.Windows.Forms.Padding(4);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(111, 48);
            this.calcButton.TabIndex = 13;
            this.calcButton.Text = "Calculate Grade:";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 205);
            this.Controls.Add(this.calculatedLbl);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.WPMBox);
            this.Controls.Add(this.WPMLbl);
            this.Name = "Form1";
            this.Text = "Lab7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WPMLbl;
        private System.Windows.Forms.TextBox WPMBox;
        private System.Windows.Forms.Label calculatedLbl;
        private System.Windows.Forms.Button calcButton;
    }
}


﻿// Grading ID:      M7874
// Lab Number:      Lab 5
// Due Date:        3/3/19
// Course Section:  199-01
//Discription:      This program takes entered temperatures and outputs the number of temps entered and the mean of the temps entered.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            int temp,          // sets temp as an int veriable
                total = 0,     // sets and declares total as an int variaable
                count = 0;     // sets and declares count as an int variable

            WriteLine("Enter Temperatures from -20 to 130 (999 to stop)");    // This writes out what the user needs to do

            Write("Enter Temperature: ");                        // writes out enter temperature on the next line
            temp = int.Parse(ReadLine());


            while (temp != 999)                             // sets a while loop, this loop will continue as long as temp != 999.
            {
                if (temp >= -20 && temp <= 130)             // within loop, if the temp is within a range do the following.
                {
                    total += temp;                          // total is one more than temp
                    count++;                                // 1 is added to temp
                }
                else                                        // otherwise section of the if
                {
                    WriteLine("Invalid Temperature");       // if the above isnt true then write invalid temperature
                }
                Write("Enter Temperature: ");               // after the if statement is complete ask for a temperature
                temp = int.Parse(ReadLine());               // and read the value from the line as an int
            }

            WriteLine($"You entered {count} valid temperatures.");                         // once the loop is broken a line will be written stating the count
            WriteLine($"The Mean temperature is {total * 1.0 / count * 1.0} degrees.");    // and the average of the numbers entered
            ReadLine();                          
        }
    }
}

﻿// Grading ID:      M7874
// Program Number:  Program 1
// Due Date:        Tuesday, Feb. 12
// Course Section:  199-01
// Discription:     This program estimates the price one would pay for carpet based on their needs 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            double width,                 // declares width as double
                length,                   // declares length as double
                price,                    // declares price as double
                YARDS_NEEDED,
                CARPET_COST,
                PADDING_COST,
                LABOR_COST,
                TOTAL_COST;
            int padding,                  // declares padding as int
                room;                     // declares coom as int
            const double FEET2YARD = 9,   // declares FEET2YARD as a constant double
                WASTE = 1.1,              // declares WASTE as a constant double
                PADDING_PRICE =2.75,      // declares PADDING_PRICE as a constant double
                ROOM1_LABOR = 100,        // declares ROOM1_LABOR as a constant double 
                LABOR_RATE = 4.50;        // declares LABOR_RATE as a constant double

            WriteLine("Welcome to the Handy-Dandy Carpet Estimator");      // writes the title
            WriteLine();                                                   // writes a blank line
            Write("Enter the max width of room (in feet): ");              // writes the first command
            width = double.Parse(ReadLine());                              // converts user imput to double
            Write("Enter the max length of room (in feet): ");             // writes the second command
            length = double.Parse(ReadLine());                             // converts user imput to double
            Write("Enter the carpet price (per sq. yard): ");              // writes the third command
            price = double.Parse(ReadLine());                              // converts user imput to double
            Write("Enter layers of padding to use (1 or 2): ");            // writes the fourth command
            padding = int.Parse(ReadLine());                               // converts user imput to double
            Write("Is this the first room? (1 = Yes, 0 = NO): ");          // writes the fifth command
            room = int.Parse(ReadLine());                                  // converts user imput to double
            WriteLine();                                                   // writes a blank line





            YARDS_NEEDED = (width * length) / FEET2YARD;                          // declares YARDS_NEEDED with the stated math                  
            WriteLine($"Sq. Yards Needed: {YARDS_NEEDED,10:N}");                  // writes a line with the declared YARDS_NEEDED variable
            CARPET_COST = WASTE * (price * YARDS_NEEDED);                         // declares CARPET_COST with the stated math
            WriteLine($"Carpet Cost: {CARPET_COST,15:C}");                        // writes a line with the declared CARPET_COST variable
            PADDING_COST = WASTE * (PADDING_PRICE * YARDS_NEEDED);                // declares PADDING_COST with the stated math
            WriteLine($"Padding Cost: {PADDING_COST,14:C}");                      // writes a line with the declared PADDING_COST variable
            if (room == 1)                                                        // if the room is equal to 1 then do the following
            {
                LABOR_COST = ROOM1_LABOR + (LABOR_RATE * YARDS_NEEDED);
            }
            else                                                                  // otherwise do the following
            {
                LABOR_COST = LABOR_RATE * YARDS_NEEDED;
            }
            WriteLine($"Labor Cost: {LABOR_COST,16:C}");                            // writes a line with the declared LABOR_COST variable
            TOTAL_COST = CARPET_COST + PADDING_COST + LABOR_COST;                   // declares TOTAL_COST with the stated math
            WriteLine($"Total Cost: {TOTAL_COST,16:C}");                            // writes a line with the declared TOTAL_COST variable

        }
    }
}

﻿// Program 4
// CIS 199-01
// Due: 4/23/2019
// M7874

// This program displays shipping information and allows the user to change some of the values

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Program4
{
    // main class where everything gets output
    class Program
    {
        static void Main(string[] args)
        {
            // objects that are created from GroundPackage.cs
            GroundPackage gp1 = new GroundPackage(40299, 19987, 47, 15, 17, 47);
            GroundPackage gp2 = new GroundPackage(1391, 89743, 37, 84, 42, 15);
            GroundPackage gp3 = new GroundPackage(50405, 40209, 50, 70, 1, 254);
            GroundPackage gp4 = new GroundPackage(34765, 9529, 47, 55.86, 32, 87);
            GroundPackage gp5 = new GroundPackage(90210, 43578, 69, 82, 49, 420);

            GroundPackage[] packages = { gp1, gp2, gp3, gp4, gp5 };   // this array stores the objects in the packages array

            DisplayPackages(packages);                                // calls the function to display

            // changes the GroundPackage and displays it
            gp1.OriginalZip = 17380;
            gp1.Length = 42;
            display(gp1);
        }
        // pulls the data from the main method and displays it
        static void DisplayPackages(GroundPackage[] packages)
        {
            // loop from the packages array
            for (int i = 0; i < packages.Length; i++)
            {
                WriteLine("Package " + (i + 1) + "\n-----------------------------");
                WriteLine(packages[i]);
                WriteLine($"{"Shipping Cost",-19} : ${packages[i].CalcCost()}");
                WriteLine();
            }
        }
        // pulls data from the main method and displays it
        static void display(GroundPackage package)
        {
            WriteLine(package);
            WriteLine($"{"Shipping Cost",-20} : ${package.CalcCost()}");
            WriteLine();
        }
    }
}

﻿using System;

namespace Program4
{
    // this class does all of the arithmatic for the main
    class GroundPackage
    {
        //primary data
        private int originZip;
        private int destinationZip;
        private int zoneDistance;
        private double length;
        private double width;
        private double height;
        private double weight;

        //initializes the primary data
        // used properties to set values
        public GroundPackage(int o, int d, double l, double wi, double h, double we)
        {
            OriginalZip = o;
            DestinationZip = d;
            Length = l;
            Height = h;
            Width = wi;
            Weight = we;

        }

        //properties for all the primary data
        public int OriginalZip
        {
            get { return originZip; }
            set
            {
                // if value isn't valid set to 40202
                if (value >= 10000 && value <= 99999)
                    originZip = value;
                else
                    originZip = 40202;
            }
        }
        //properties for all the primary data
        public int DestinationZip
        {
            get { return destinationZip; }
            set
            {
                // if value isn't valid set to 90210
                if (value >= 10000 && value <= 99999)
                    destinationZip = value;
                else
                    destinationZip = 90210;
            }
        }
        //properties for all the primary data
        public double Length
        {
            get { return length; }
            set
            {
                // if value isn't valid set to 1
                if (value > 0)
                    length = value;
                else
                    length = 1.0;
            }
        }
        //properties for all the primary data
        public double Width
        {
            get { return width; }
            set
            {
                // if value isn't valid set to 1
                if (value > 0)
                    width = value;
                else
                    width = 1.0;
            }
        }
        //properties for all the primary data
        public double Height
        {
            get { return height; }
            set
            {
                // if value isn't valid set to 1
                if (value > 0)
                    height = value;
                else
                    height = 1.0;
            }
        }
        //properties for all the primary data
        public double Weight
        {
            get { return weight; }
            set
            {
                // if value isn't valid set to 1
                if (value > 0)
                    weight = value;
                else
                    weight = 1.0;
            }
        }
        //properties for all the primary data
        public int ZoneDistance
        {
            get
            {
                int firstO = OriginalZip / 10000;           // find first digit of OriginZip
                int firstD = DestinationZip / 10000;        // find first digit of DestinationZip
                return Math.Abs(firstO - firstD);           // return absolute value of above
            }
        }

        // the string length is set to left with 20 characters
        public override string ToString()
        {
            return $"{"Origin ZipCode",-20}: {OriginalZip}" + Environment.NewLine +
                   $"{"Destination ZipCode",-20}: {DestinationZip}" + Environment.NewLine +
                   $"{"Length",-20}: {Length}" + Environment.NewLine +
                   $"{"Height",-20}: {Height}" + Environment.NewLine +
                   $"{"Width",-20}: {Width}" + Environment.NewLine +
                   $"{"Weight",-20}: {Weight}";
        }

        // calc the cost and the return
        public double CalcCost()
        {
            double cost = .25 * (Length + Width + Height) + .45 * (ZoneDistance + 1) * (Weight);
            return cost;
        }
    }
}

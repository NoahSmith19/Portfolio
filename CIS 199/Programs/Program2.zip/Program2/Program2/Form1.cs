﻿// Grading ID:      M7874
// Program Number:  Program 2
// Due Date:        3/5/19
// Course Section:  199-01
//Discription:      This form takes user input of taxable income and filing status and outputs the users tax bracket and marginal income tax.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // This is the argument for clicking the calculate button
        private void calcButton_Click(object sender, EventArgs e)
        {
            double taxableIncome,
                calculated1,                    // declares calculated 37 as double
                calculated2,                    // declares calculated 35 as double
                calculated3,                    // declares calculated 32 as double
                calculated4,                    // declares calculated 24 as double
                calculated5,                    // declares calculated 22 as double
                calculated6,                    // declares calculated 12 as double
                calculated7,                    // declares calculated 10 as double
                percent7 = .37,                 // sets 37% as a constant
                percent6 = .35,                 // sets 35% as a constant
                percent5 = .32,                 // sets 32% as a constant
                percent4 = .24,                 // sets 24% as a constant
                percent3 = .22,                 // sets 22% as a constant
                percent2 = .12,                 // sets 12% as a constant
                percent1 = .10,                 // sets 10% as a constant
                single1max = 9700,              // sets 9700 as a constant for filing single with a 10% rate
                single2max = 39475,             // sets 39475 as a constant for filing single with a 12% rate
                single3max = 84200,             // sets 84200 as a constant for filing single with a 22% rate
                single4max = 160725,            // sets 160725 as a constant for filing single with a 24% rate
                single5max = 204100,            // sets 204100 as a constant for filing single with a 32% rate
                single6max = 510300,            // sets 510300 as a constant for filing single with a 35% rate
                marriedJoint1max = 19400,       // sets 19400 as a constant for filing jointly with a 10% rate
                marriedJoint2max = 78950,       // sets 78950 as a constant for filing jointly with a 12% rate
                marriedJoint3max = 168400,      // sets 168400 as a constant for filing jointly with a 22% rate
                marriedJoint4max = 321450,      // sets 321450 as a constant for filing jointly with a 24% rate
                marriedJoint5max = 408200,      // sets 408200 as a constant for filing jointly with a 32% rate
                marriedJoint6max = 612350,      // sets 612350 as a constant for filing jointly with a 35% rate
                head1max = 13850,               // sets 13850 as a constant for filing as head with a 10% rate
                head2max = 52850,               // sets 52850 as a constant for filing as head with a 12% rate
                head3max = 84200,               // sets 84200 as a constant for filing as head with a 22% rate
                head4max = 160700,              // sets 160700 as a constant for filing as head with a 24% rate
                head5max = 204100,              // sets 204100 as a constant for filing as head with a 32% rate
                head6max = 510300,              // sets 510300 as a constant for filing as head with a 35% rate
                marriedSeperate1max = 9700,     // sets 9700 as a constant for filing seperate with a 10% rate
                marriedSeperate2max = 39475,    // sets 39475 as a constant for filing seperate with a 12% rate
                marriedSeperate3max = 84200,    // sets 84200 as a constant for filing seperate with a 22% rate
                marriedSeperate4max = 160725,   // sets 160725 as a constant for filing seperate with a 24% rate
                marriedSeperate5max = 204100,   // sets 204100 as a constant for filing seperate with a 32% rate
                marriedSeperate6max = 306175;   // sets 303175 as a constant for filing seperate with a 35% rate


            // This if statements reads the value in taxableIncomeBox and turns it into taxableIncome if it can
            if (double.TryParse(taxableIncomeBox.Text, out taxableIncome))
            {
                // checks if SingleRB is checked
                if (SingleRB.Checked)
                {
                    // if SingleRb is checked then do the following
                    if (taxableIncome <= single1max)
                    {
                        calculated7 = taxableIncome * percent1;              // sets calculated10 to taxableIncome * percent10
                        calculatedBox.Text = $"Tax Rate: {percent1:P} " + $"Tax Due: {calculated7:C}";      // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= single2max)
                    {
                        calculated6 = (single1max * percent1) + ((taxableIncome - single1max) * percent2);    // sets calculated12 to (taxableIncome - single10max) * percent 12 and adds that to the calculated10
                        calculatedBox.Text = $"Tax Rate: {percent2:P} " + $"Tax Due: {calculated6:C}";      // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= single3max)
                    {
                        calculated5 = (single1max * percent1) + ((single2max - single1max) * percent2) + ((taxableIncome - single2max) * percent3);    //calculates the value if you are within the 22% bracket
                        calculatedBox.Text = $"Tax Rate: {percent3:P} " + $"Tax Due: {calculated5:C}";      // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= single4max)
                    {
                        calculated4 = (single1max * percent1) + ((single2max - single1max) * percent2) + ((single3max - single2max) * percent3) + ((taxableIncome - single3max) * percent4);    //calculates the value if you are within the 24% bracket
                        calculatedBox.Text = $"Tax Rate: {percent4:P} " + $"Tax Due: {calculated4:C}";      // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= single5max)
                    {
                        calculated3 = (single1max * percent1) + ((single2max - single1max) * percent2) + ((single3max - single2max) * percent3) + ((single4max - single3max) * percent4) + ((taxableIncome - single4max) * percent5);    //calculates the value if you are within the 32% bracket
                        calculatedBox.Text = $"Tax Rate: {percent5:P} " + $"Tax Due: {calculated3:C}";      // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= single6max)
                    {
                        calculated2 = (single1max * percent1) + ((single2max - single1max) * percent2) + ((single3max - single2max) * percent3) + ((single4max - single3max) * percent4) + ((single5max - single4max) * percent5) + ((taxableIncome - single5max) * percent6);    //calculates the value if you are within the 37% bracket
                        calculatedBox.Text = $"Tax Rate: {percent6:P} " + $"Tax Due: {calculated2:C}";      // output with your tax bracket and your calculated tax
                    }
                    else
                    {
                        calculated1 = (single1max * percent1) + ((single2max - single1max) * percent2) + ((single3max - single2max) * percent3) + ((single4max - single3max) * percent4) + ((single5max - single4max) * percent5) + ((single6max - single5max) * percent6) + ((taxableIncome - single6max) * percent7);   //calculates the value if you are within the 37% bracket
                        calculatedBox.Text = $"Tax Rate: {percent7:P} " + $"Tax Due: {calculated1:C}";      // output with your tax bracket and your calculated tax
                    }
                }
                // checks if marriedJointlyRB is checked
                else if (marriedJointlyRB.Checked)
                {
                    // if marriedJointlyRB is checked then do the following
                    if (taxableIncome <= marriedJoint1max)
                    {
                        calculated7 = taxableIncome * percent1;           //calculates the value if you are within the 10% bracket
                        calculatedBox.Text = $"Tax Rate: {percent1:P} " + $"Tax Due: {calculated7:C}";   // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedJoint2max)
                    {
                        calculated6 = (marriedJoint1max * percent1) + ((taxableIncome - marriedJoint1max) * percent2);    //calculates the value if you are within the 12% bracket
                        calculatedBox.Text = $"Tax Rate: {percent2:P} " + $"Tax Due: {calculated6:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedJoint3max)
                    {
                        calculated5 = (marriedJoint1max * percent1) + ((marriedJoint2max - marriedJoint1max) * percent2) + ((taxableIncome - marriedJoint2max) * percent3);    //calculates the value if you are within the 22% bracket
                        calculatedBox.Text = $"Tax Rate: {percent3:P} " + $"Tax Due: {calculated5:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedJoint4max)
                    {
                        calculated4 = (marriedJoint1max * percent1) + ((marriedJoint2max - marriedJoint1max) * percent2) + ((marriedJoint3max - marriedJoint2max) * percent3) + ((taxableIncome - marriedJoint3max) * percent4);    //calculates the value if you are within the 24% bracket
                        calculatedBox.Text = $"Tax Rate: {percent4:P} " + $"Tax Due: {calculated4:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedJoint5max)
                    {
                        calculated3 = (marriedJoint1max * percent1) + ((marriedJoint2max - marriedJoint1max) * percent2) + ((marriedJoint3max - marriedJoint2max) * percent3) + ((marriedJoint4max - marriedJoint3max) * percent4) + ((taxableIncome - marriedJoint4max) * percent5);    //calculates the value if you are within the 32% bracket
                        calculatedBox.Text = $"Tax Rate: {percent5:P} " + $"Tax Due: {calculated3:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedJoint6max)
                    {
                        calculated2 = (marriedJoint1max * percent1) + ((marriedJoint2max - marriedJoint1max) * percent2) + ((marriedJoint3max - marriedJoint2max) * percent3) + ((marriedJoint4max - marriedJoint3max) * percent4) + ((marriedJoint5max -marriedJoint4max) * percent5) + ((taxableIncome - marriedJoint5max) * percent6);    //calculates the value if you are within the 35% bracket
                        calculatedBox.Text = $"Tax Rate: {percent6:P} " + $"Tax Due: {calculated2:C}";    // output with your tax bracket and your calculated tax
                    }
                    else
                    {
                        calculated1 = (marriedJoint1max * percent1) + ((marriedJoint2max - marriedJoint1max) * percent2) + ((marriedJoint3max - marriedJoint2max) * percent3) + ((marriedJoint4max - marriedJoint3max) * percent4) + ((marriedJoint5max - marriedJoint4max) * percent5) + ((marriedJoint6max - marriedJoint5max) * percent6) + ((taxableIncome - marriedJoint6max) * percent7);    //calculates the value if you are within the 37% bracket
                        calculatedBox.Text = $"Tax Rate: {percent7:P} " + $"Tax Due: {calculated1:C}";    // output with your tax bracket and your calculated tax
                    }
                }
                // checks if headRB is checked
                else if (headRB.Checked)
                {
                    // if headRB is checked then do the following
                    if (taxableIncome <= head1max)
                    {
                        calculated7 = taxableIncome * percent1;           //calculates the value if you are within the 10% bracket
                        calculatedBox.Text = $"Tax Rate: {percent1:P} " + $"Tax Due: {calculated7:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= head2max)
                    {
                        calculated6 = (head1max * percent1) + ((taxableIncome - head1max) * percent2);    //calculates the value if you are within the 12% bracket
                        calculatedBox.Text = $"Tax Rate: {percent2:P} " + $"Tax Due: {calculated6:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= head3max)
                    {
                        calculated5 = (head1max * percent1) + ((head2max - head1max) * percent2) + ((taxableIncome - head2max) * percent3);    //calculates the value if you are within the 22% bracket
                        calculatedBox.Text = $"Tax Rate: {percent3:P} " + $"Tax Due: {calculated5:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= head4max)
                    {
                        calculated4 = (head1max * percent1) + ((head2max - head1max) * percent2) + ((head3max - head2max) * percent3) + ((taxableIncome - head3max) * percent4);    //calculates the value if you are within the 24% bracket
                        calculatedBox.Text = $"Tax Rate: {percent4:P} " + $"Tax Due: {calculated4:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= head5max)
                    {
                        calculated3 = (head1max * percent1) + ((head2max - head1max) * percent2) + ((head3max - head2max) * percent3) + ((head4max - head3max) * percent4) + ((taxableIncome - head4max) * percent5);    //calculates the value if you are within the 32% bracket
                        calculatedBox.Text = $"Tax Rate: {percent5:P} " + $"Tax Due: {calculated3:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= head6max)
                    {
                        calculated2 = (head1max * percent1) + ((head2max - head1max) * percent2) + ((head3max - head2max) * percent3) + ((head4max - head3max) * percent4) + ((head5max - head4max) * percent5) + ((taxableIncome - head5max) * percent6);    //calculates the value if you are within the 35% bracket
                        calculatedBox.Text = $"Tax Rate: {percent6:P} " + $"Tax Due: {calculated2:C}";    // output with your tax bracket and your calculated tax
                    }
                    else
                    {
                        calculated1 = (head1max * percent1) + ((head2max - head1max) * percent2) + ((head3max - head2max) * percent3) + ((head4max - head3max) * percent4) + ((head5max - head4max) * percent5) + ((head6max - head5max) * percent6) + ((taxableIncome - head6max) * percent7);    //calculates the value if you are within the 37% bracket
                        calculatedBox.Text = $"Tax Rate: {percent7:P} " + $"Tax Due: {calculated1:C}";    // output with your tax bracket and your calculated tax
                    }
                }
                // checks if marriedSeperatelyRB is checked
                else if (marriedSeperatelyRB.Checked)
                {
                    // if marriedSeperateltRB is checked then do the following
                    if (taxableIncome <= marriedSeperate1max)
                    {
                        calculated7 = taxableIncome * percent1;            //calculates the value if you are within the 10% bracket
                        calculatedBox.Text = $"Tax Rate: {percent1:P} " + $"Tax Due: {calculated7:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedSeperate2max)
                    {
                        calculated6 = (marriedSeperate1max * percent1) + ((taxableIncome - marriedSeperate1max) * percent2);    //calculates the value if you are within the 12% bracket
                        calculatedBox.Text = $"Tax Rate: {percent2:P} " + $"Tax Due: {calculated6:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedSeperate3max)
                    {
                        calculated5 = (marriedSeperate1max * percent1) + ((marriedSeperate2max - marriedSeperate1max) * percent2) + ((taxableIncome - marriedSeperate2max) * percent3);    //calculates the value if you are within the 22% bracket
                        calculatedBox.Text = $"Tax Rate: {percent3:P} " + $"Tax Due: {calculated5:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedSeperate4max)
                    {
                        calculated4 = (marriedSeperate1max * percent1) + ((marriedSeperate2max - marriedSeperate1max) * percent2) + ((marriedSeperate3max - marriedSeperate2max) * percent3) + ((taxableIncome - marriedSeperate3max) * percent4);    //calculates the value if you are within the 24% bracket
                        calculatedBox.Text = $"Tax Rate: {percent4:P} " + $"Tax Due: {calculated4:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedSeperate5max)
                    {
                        calculated3 = (marriedSeperate1max * percent1) + ((marriedSeperate2max - marriedSeperate1max) * percent2) + ((marriedSeperate3max - marriedSeperate2max) * percent3) + ((marriedSeperate4max - marriedSeperate3max) * percent4) + ((taxableIncome - marriedSeperate4max) * percent5);    //calculates the value if you are within the 32% bracket
                        calculatedBox.Text = $"Tax Rate: {percent5:P} " + $"Tax Due: {calculated3:C}";    // output with your tax bracket and your calculated tax
                    }
                    else if (taxableIncome <= marriedSeperate6max)
                    {
                        calculated2 = (marriedSeperate1max * percent1) + ((marriedSeperate2max - marriedSeperate1max) * percent2) + ((marriedSeperate3max - marriedSeperate2max) * percent3) + ((marriedSeperate4max - marriedSeperate3max) * percent4) + ((marriedSeperate5max - marriedSeperate4max) * percent5) + ((taxableIncome - marriedSeperate5max) * percent6);    //calculates the value if you are within the 35% bracket
                        calculatedBox.Text = $"Tax Rate: {percent6:P} " + $"Tax Due: {calculated2:C}";    // output with your tax bracket and your calculated tax
                    }
                    else
                    {
                        calculated1 = (marriedSeperate1max * percent1) + ((marriedSeperate2max - marriedSeperate1max) * percent2) + ((marriedSeperate3max - marriedSeperate2max) * percent3) + ((marriedSeperate4max - marriedSeperate3max) * percent4) + ((marriedSeperate5max - marriedSeperate4max) * percent5) + ((marriedSeperate6max - marriedSeperate5max) * percent6) + ((taxableIncome - marriedSeperate6max) * percent7);    //calculates the value if you are within the 37% bracket
                        calculatedBox.Text = $"Tax Rate: {percent7:P} " + $"Tax Due: {calculated1:C}";    // output with your tax bracket and your calculated tax
                    }
                }
            }
            // if taxableIncomeBox cant be parsed then an error message is diplayed
            else                                                               
            {
                MessageBox.Show("Enter a valid Income");                                          
            }

        }
    }
}

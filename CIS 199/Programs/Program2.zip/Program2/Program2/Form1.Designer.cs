﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SingleRB = new System.Windows.Forms.RadioButton();
            this.marriedJointlyRB = new System.Windows.Forms.RadioButton();
            this.headRB = new System.Windows.Forms.RadioButton();
            this.marriedSeperatelyRB = new System.Windows.Forms.RadioButton();
            this.filingStatusLbl = new System.Windows.Forms.Label();
            this.taxableIncomeLbl = new System.Windows.Forms.Label();
            this.taxableIncomeBox = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.calculatedBox = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SingleRB
            // 
            this.SingleRB.AutoSize = true;
            this.SingleRB.Location = new System.Drawing.Point(164, 63);
            this.SingleRB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SingleRB.Name = "SingleRB";
            this.SingleRB.Size = new System.Drawing.Size(68, 21);
            this.SingleRB.TabIndex = 0;
            this.SingleRB.TabStop = true;
            this.SingleRB.Text = "Single";
            this.SingleRB.UseVisualStyleBackColor = true;
            // 
            // marriedJointlyRB
            // 
            this.marriedJointlyRB.AutoSize = true;
            this.marriedJointlyRB.Location = new System.Drawing.Point(164, 87);
            this.marriedJointlyRB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.marriedJointlyRB.Name = "marriedJointlyRB";
            this.marriedJointlyRB.Size = new System.Drawing.Size(158, 21);
            this.marriedJointlyRB.TabIndex = 1;
            this.marriedJointlyRB.TabStop = true;
            this.marriedJointlyRB.Text = "Married Filing Jointly";
            this.marriedJointlyRB.UseVisualStyleBackColor = true;
            // 
            // headRB
            // 
            this.headRB.AutoSize = true;
            this.headRB.Location = new System.Drawing.Point(164, 111);
            this.headRB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.headRB.Name = "headRB";
            this.headRB.Size = new System.Drawing.Size(151, 21);
            this.headRB.TabIndex = 2;
            this.headRB.TabStop = true;
            this.headRB.Text = "Head of Household";
            this.headRB.UseVisualStyleBackColor = true;
            // 
            // marriedSeperatelyRB
            // 
            this.marriedSeperatelyRB.AutoSize = true;
            this.marriedSeperatelyRB.Location = new System.Drawing.Point(164, 135);
            this.marriedSeperatelyRB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.marriedSeperatelyRB.Name = "marriedSeperatelyRB";
            this.marriedSeperatelyRB.Size = new System.Drawing.Size(186, 21);
            this.marriedSeperatelyRB.TabIndex = 3;
            this.marriedSeperatelyRB.TabStop = true;
            this.marriedSeperatelyRB.Text = "Married Filing Seperately";
            this.marriedSeperatelyRB.UseVisualStyleBackColor = true;
            // 
            // filingStatusLbl
            // 
            this.filingStatusLbl.AutoSize = true;
            this.filingStatusLbl.Location = new System.Drawing.Point(27, 63);
            this.filingStatusLbl.Name = "filingStatusLbl";
            this.filingStatusLbl.Size = new System.Drawing.Size(89, 17);
            this.filingStatusLbl.TabIndex = 9;
            this.filingStatusLbl.Text = "Filing Status:";
            // 
            // taxableIncomeLbl
            // 
            this.taxableIncomeLbl.AutoSize = true;
            this.taxableIncomeLbl.Location = new System.Drawing.Point(27, 23);
            this.taxableIncomeLbl.Name = "taxableIncomeLbl";
            this.taxableIncomeLbl.Size = new System.Drawing.Size(111, 17);
            this.taxableIncomeLbl.TabIndex = 10;
            this.taxableIncomeLbl.Text = "Taxable Income:";
            // 
            // taxableIncomeBox
            // 
            this.taxableIncomeBox.Location = new System.Drawing.Point(164, 23);
            this.taxableIncomeBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.taxableIncomeBox.Name = "taxableIncomeBox";
            this.taxableIncomeBox.Size = new System.Drawing.Size(89, 22);
            this.taxableIncomeBox.TabIndex = 11;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(164, 190);
            this.calcButton.Margin = new System.Windows.Forms.Padding(4);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(100, 28);
            this.calcButton.TabIndex = 12;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // calculatedBox
            // 
            this.calculatedBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calculatedBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculatedBox.Location = new System.Drawing.Point(129, 222);
            this.calculatedBox.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.calculatedBox.Name = "calculatedBox";
            this.calculatedBox.Size = new System.Drawing.Size(170, 65);
            this.calculatedBox.TabIndex = 13;
            this.calculatedBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 305);
            this.Controls.Add(this.calculatedBox);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.taxableIncomeBox);
            this.Controls.Add(this.taxableIncomeLbl);
            this.Controls.Add(this.filingStatusLbl);
            this.Controls.Add(this.marriedSeperatelyRB);
            this.Controls.Add(this.headRB);
            this.Controls.Add(this.marriedJointlyRB);
            this.Controls.Add(this.SingleRB);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Program2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton SingleRB;
        private System.Windows.Forms.RadioButton marriedJointlyRB;
        private System.Windows.Forms.RadioButton headRB;
        private System.Windows.Forms.RadioButton marriedSeperatelyRB;
        private System.Windows.Forms.Label filingStatusLbl;
        private System.Windows.Forms.Label taxableIncomeLbl;
        private System.Windows.Forms.TextBox taxableIncomeBox;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label calculatedBox;
    }
}


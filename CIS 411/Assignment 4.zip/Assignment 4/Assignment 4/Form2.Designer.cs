﻿namespace Assignment_4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.PMILbl = new System.Windows.Forms.Label();
            this.CalculateBtn = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.PropertyTaxLbl = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LoanTermUpDown = new System.Windows.Forms.NumericUpDown();
            this.LoanTermLabel = new System.Windows.Forms.Label();
            this.MonthlyPaymentLbl = new System.Windows.Forms.Label();
            this.DownPaymentLbl = new System.Windows.Forms.Label();
            this.InterestLbl = new System.Windows.Forms.Label();
            this.PurchasePriceLbl = new System.Windows.Forms.Label();
            this.InterestUpDown = new System.Windows.Forms.NumericUpDown();
            this.DownPaymentTextBox = new System.Windows.Forms.TextBox();
            this.PropertyTaxTextBox = new System.Windows.Forms.TextBox();
            this.PMITextBox = new System.Windows.Forms.TextBox();
            this.MonthlyPaymentTextBox = new System.Windows.Forms.TextBox();
            this.PurchasePriceTextBox = new System.Windows.Forms.TextBox();
            this.OutputDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.LoanTermUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InterestUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OutputDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(253, 186);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 17);
            this.label11.TabIndex = 36;
            this.label11.Text = "per year.";
            // 
            // PMILbl
            // 
            this.PMILbl.AutoSize = true;
            this.PMILbl.Location = new System.Drawing.Point(23, 235);
            this.PMILbl.Name = "PMILbl";
            this.PMILbl.Size = new System.Drawing.Size(107, 17);
            this.PMILbl.TabIndex = 35;
            this.PMILbl.Text = "PMI (Insurance)";
            // 
            // CalculateBtn
            // 
            this.CalculateBtn.Location = new System.Drawing.Point(85, 327);
            this.CalculateBtn.Name = "CalculateBtn";
            this.CalculateBtn.Size = new System.Drawing.Size(101, 45);
            this.CalculateBtn.TabIndex = 27;
            this.CalculateBtn.Text = "Calculate";
            this.CalculateBtn.UseVisualStyleBackColor = true;
            this.CalculateBtn.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(253, 235);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 17);
            this.label9.TabIndex = 34;
            this.label9.Text = "per year.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(178, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 17);
            this.label8.TabIndex = 33;
            this.label8.Text = "%";
            // 
            // PropertyTaxLbl
            // 
            this.PropertyTaxLbl.AutoSize = true;
            this.PropertyTaxLbl.Location = new System.Drawing.Point(23, 186);
            this.PropertyTaxLbl.Name = "PropertyTaxLbl";
            this.PropertyTaxLbl.Size = new System.Drawing.Size(93, 17);
            this.PropertyTaxLbl.TabIndex = 32;
            this.PropertyTaxLbl.Text = "Property Tax:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(178, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 17);
            this.label7.TabIndex = 31;
            this.label7.Text = "years.";
            // 
            // LoanTermUpDown
            // 
            this.LoanTermUpDown.Location = new System.Drawing.Point(110, 60);
            this.LoanTermUpDown.Name = "LoanTermUpDown";
            this.LoanTermUpDown.Size = new System.Drawing.Size(62, 22);
            this.LoanTermUpDown.TabIndex = 23;
            this.LoanTermUpDown.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // LoanTermLabel
            // 
            this.LoanTermLabel.AutoSize = true;
            this.LoanTermLabel.Location = new System.Drawing.Point(23, 65);
            this.LoanTermLabel.Name = "LoanTermLabel";
            this.LoanTermLabel.Size = new System.Drawing.Size(81, 17);
            this.LoanTermLabel.TabIndex = 30;
            this.LoanTermLabel.Text = "Loan Term:";
            // 
            // MonthlyPaymentLbl
            // 
            this.MonthlyPaymentLbl.AutoSize = true;
            this.MonthlyPaymentLbl.Location = new System.Drawing.Point(23, 277);
            this.MonthlyPaymentLbl.Name = "MonthlyPaymentLbl";
            this.MonthlyPaymentLbl.Size = new System.Drawing.Size(120, 17);
            this.MonthlyPaymentLbl.TabIndex = 29;
            this.MonthlyPaymentLbl.Text = "Monthly Payment:";
            // 
            // DownPaymentLbl
            // 
            this.DownPaymentLbl.AutoSize = true;
            this.DownPaymentLbl.Location = new System.Drawing.Point(23, 140);
            this.DownPaymentLbl.Name = "DownPaymentLbl";
            this.DownPaymentLbl.Size = new System.Drawing.Size(106, 17);
            this.DownPaymentLbl.TabIndex = 28;
            this.DownPaymentLbl.Text = "Down Payment:";
            // 
            // InterestLbl
            // 
            this.InterestLbl.AutoSize = true;
            this.InterestLbl.Location = new System.Drawing.Point(23, 97);
            this.InterestLbl.Name = "InterestLbl";
            this.InterestLbl.Size = new System.Drawing.Size(59, 17);
            this.InterestLbl.TabIndex = 26;
            this.InterestLbl.Text = "Interest:";
            // 
            // PurchasePriceLbl
            // 
            this.PurchasePriceLbl.AutoSize = true;
            this.PurchasePriceLbl.Location = new System.Drawing.Point(23, 18);
            this.PurchasePriceLbl.Name = "PurchasePriceLbl";
            this.PurchasePriceLbl.Size = new System.Drawing.Size(108, 17);
            this.PurchasePriceLbl.TabIndex = 24;
            this.PurchasePriceLbl.Text = "Purchase Price:";
            // 
            // InterestUpDown
            // 
            this.InterestUpDown.DecimalPlaces = 4;
            this.InterestUpDown.Increment = new decimal(new int[] {
            125,
            0,
            0,
            196608});
            this.InterestUpDown.Location = new System.Drawing.Point(110, 95);
            this.InterestUpDown.Name = "InterestUpDown";
            this.InterestUpDown.Size = new System.Drawing.Size(62, 22);
            this.InterestUpDown.TabIndex = 25;
            this.InterestUpDown.Value = new decimal(new int[] {
            6,
            0,
            0,
            0});
            // 
            // DownPaymentTextBox
            // 
            this.DownPaymentTextBox.Location = new System.Drawing.Point(147, 140);
            this.DownPaymentTextBox.Name = "DownPaymentTextBox";
            this.DownPaymentTextBox.Size = new System.Drawing.Size(100, 22);
            this.DownPaymentTextBox.TabIndex = 37;
            // 
            // PropertyTaxTextBox
            // 
            this.PropertyTaxTextBox.Location = new System.Drawing.Point(147, 183);
            this.PropertyTaxTextBox.Name = "PropertyTaxTextBox";
            this.PropertyTaxTextBox.Size = new System.Drawing.Size(100, 22);
            this.PropertyTaxTextBox.TabIndex = 38;
            // 
            // PMITextBox
            // 
            this.PMITextBox.Location = new System.Drawing.Point(149, 235);
            this.PMITextBox.Name = "PMITextBox";
            this.PMITextBox.Size = new System.Drawing.Size(100, 22);
            this.PMITextBox.TabIndex = 39;
            // 
            // MonthlyPaymentTextBox
            // 
            this.MonthlyPaymentTextBox.Location = new System.Drawing.Point(149, 277);
            this.MonthlyPaymentTextBox.Name = "MonthlyPaymentTextBox";
            this.MonthlyPaymentTextBox.Size = new System.Drawing.Size(100, 22);
            this.MonthlyPaymentTextBox.TabIndex = 40;
            // 
            // PurchasePriceTextBox
            // 
            this.PurchasePriceTextBox.Location = new System.Drawing.Point(157, 19);
            this.PurchasePriceTextBox.Name = "PurchasePriceTextBox";
            this.PurchasePriceTextBox.Size = new System.Drawing.Size(100, 22);
            this.PurchasePriceTextBox.TabIndex = 41;
            // 
            // OutputDataGridView
            // 
            this.OutputDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OutputDataGridView.Location = new System.Drawing.Point(324, 19);
            this.OutputDataGridView.Name = "OutputDataGridView";
            this.OutputDataGridView.RowHeadersWidth = 51;
            this.OutputDataGridView.RowTemplate.Height = 24;
            this.OutputDataGridView.Size = new System.Drawing.Size(653, 499);
            this.OutputDataGridView.TabIndex = 42;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 530);
            this.Controls.Add(this.OutputDataGridView);
            this.Controls.Add(this.PurchasePriceTextBox);
            this.Controls.Add(this.MonthlyPaymentTextBox);
            this.Controls.Add(this.PMITextBox);
            this.Controls.Add(this.PropertyTaxTextBox);
            this.Controls.Add(this.DownPaymentTextBox);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.PMILbl);
            this.Controls.Add(this.CalculateBtn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.PropertyTaxLbl);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.LoanTermUpDown);
            this.Controls.Add(this.LoanTermLabel);
            this.Controls.Add(this.MonthlyPaymentLbl);
            this.Controls.Add(this.DownPaymentLbl);
            this.Controls.Add(this.InterestLbl);
            this.Controls.Add(this.PurchasePriceLbl);
            this.Controls.Add(this.InterestUpDown);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.LoanTermUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InterestUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OutputDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label PMILbl;
        private System.Windows.Forms.Button CalculateBtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label PropertyTaxLbl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown LoanTermUpDown;
        private System.Windows.Forms.Label LoanTermLabel;
        private System.Windows.Forms.Label MonthlyPaymentLbl;
        private System.Windows.Forms.Label DownPaymentLbl;
        private System.Windows.Forms.Label InterestLbl;
        private System.Windows.Forms.Label PurchasePriceLbl;
        private System.Windows.Forms.NumericUpDown InterestUpDown;
        private System.Windows.Forms.TextBox DownPaymentTextBox;
        private System.Windows.Forms.TextBox PropertyTaxTextBox;
        private System.Windows.Forms.TextBox PMITextBox;
        private System.Windows.Forms.TextBox MonthlyPaymentTextBox;
        private System.Windows.Forms.TextBox PurchasePriceTextBox;
        private System.Windows.Forms.DataGridView OutputDataGridView;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_4
{
    public struct PeriodData
    {
        public int Period { set; get; }
        public decimal EndOfPeriodBalance { set; get; }
        public decimal InterestPaid { set; get; }
        public decimal PrincipalPaid { set; get; }
    }

    public partial class Form1 : Form
    {
        List<PeriodData> Schedule = new List<PeriodData>();

        public Form1()
        {
            InitializeComponent();

            //OutputDataGridView.DataSource = Schedule;
        }

        private void SubmitBtn_Click(object sender, EventArgs e)
        {
            var principal = double.Parse(PrincipalTextBox.Text);
            var interestRate = double.Parse(InterestTextBox.Text);
            var months = double.Parse(MonthTextBox.Text);

            var monthlyRate = interestRate / 12;
            var result = principal * (interestRate * Math.Pow(1 + monthlyRate, months) / (Math.Pow(1 + monthlyRate, months) - 1));
            var result2 = principal * (monthlyRate + (monthlyRate / (Math.Pow(1 + monthlyRate, months)) ));


            MonthlyPaymentTextBox.Text = result.ToString();

            var purchasePrice = decimal.Parse(PrincipalTextBox.Text);
            var loanTerm = double.Parse(MonthTextBox.Text);
            var interest = decimal.Parse(InterestTextBox.Text);

            //var monthlyRate = interest / 12;
            //var result = purchasePrice *
            //    (interest * Math.Pow(1 + monthlyRate, loanTerm)) /
            //    (Math.Pow(1 + monthlyRate, loanTerm) - 1);
            //MonthlyPaymentTextBox.Text = result.ToString();

            RecalculateSchedule(purchasePrice, loanTerm, interest);
        }

        private void RecalculateSchedule(decimal purchasePrice, double loanTerm, decimal interest)
        {
            Schedule.Clear();

            decimal monthlyIntRate = ((interest / 100) / 12);

            Schedule.Add(new PeriodData() { Period = 0, EndOfPeriodBalance = purchasePrice, InterestPaid = 0, PrincipalPaid = 0 });

            for (int i = 1; i <= loanTerm; i++)
            {
                try
                {
                    PeriodData lastPeriod = Schedule[i - 1];

                    decimal interestPaid = lastPeriod.EndOfPeriodBalance * monthlyIntRate;

                    decimal power = (decimal)Math.Pow(1.0 + (double)monthlyIntRate, loanTerm - i + 1);
                    decimal principalPaid = (lastPeriod.EndOfPeriodBalance * monthlyIntRate * power / (power - 1)) - interestPaid;

                    decimal endBalance = lastPeriod.EndOfPeriodBalance - principalPaid;

                    Schedule.Add(new PeriodData() { Period = i, EndOfPeriodBalance = endBalance, InterestPaid = interestPaid, PrincipalPaid = principalPaid });
                }
                catch (Exception e)
                {
                    Schedule.Clear();

                    break;
                }
            }

            //OutputDataGridView.Refresh();
            OutputDataGridView.DataSource = Schedule;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_4
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            var loanAmount = double.Parse(PurchasePriceTextBox.Text);   
            //double taxesPerYear = (double)txtPropertyTax.CurrentValue;
            var downPayment = double.Parse(DownPaymentTextBox.Text);    
            var interestRate = double.Parse(InterestUpDown.Text) / 100; 
            var termOfLoan = double.Parse(LoanTermUpDown.Text) * 12;    
            var propertyTax = double.Parse(PropertyTaxTextBox.Text);    
            var insurance = double.Parse(PMITextBox.Text);

            var payment = (loanAmount - downPayment) * (Math.Pow((1 + interestRate / 12), termOfLoan) * interestRate) / (12 * (Math.Pow((1 + interestRate / 12), termOfLoan) - 1));

            payment = payment + (propertyTax + insurance) / 12;

            MonthlyPaymentTextBox.Text = payment.ToString();

            OutputDataGridView.DataSource = payment;
        }
    }
}

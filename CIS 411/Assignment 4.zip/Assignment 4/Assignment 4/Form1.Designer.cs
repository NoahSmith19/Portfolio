﻿namespace Assignment_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MonthTextBox = new System.Windows.Forms.TextBox();
            this.InterestTextBox = new System.Windows.Forms.TextBox();
            this.PrincipalTextBox = new System.Windows.Forms.TextBox();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.MonthLbl = new System.Windows.Forms.Label();
            this.InterestLbl = new System.Windows.Forms.Label();
            this.PrincipalLbl = new System.Windows.Forms.Label();
            this.MonthlyPaymentTextBox = new System.Windows.Forms.TextBox();
            this.MonthlyPaymentLbl = new System.Windows.Forms.Label();
            this.OutputDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.OutputDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // MonthTextBox
            // 
            this.MonthTextBox.Location = new System.Drawing.Point(94, 103);
            this.MonthTextBox.Name = "MonthTextBox";
            this.MonthTextBox.Size = new System.Drawing.Size(100, 22);
            this.MonthTextBox.TabIndex = 14;
            // 
            // InterestTextBox
            // 
            this.InterestTextBox.Location = new System.Drawing.Point(94, 71);
            this.InterestTextBox.Name = "InterestTextBox";
            this.InterestTextBox.Size = new System.Drawing.Size(100, 22);
            this.InterestTextBox.TabIndex = 13;
            // 
            // PrincipalTextBox
            // 
            this.PrincipalTextBox.Location = new System.Drawing.Point(94, 32);
            this.PrincipalTextBox.Name = "PrincipalTextBox";
            this.PrincipalTextBox.Size = new System.Drawing.Size(100, 22);
            this.PrincipalTextBox.TabIndex = 12;
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.Location = new System.Drawing.Point(51, 151);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(82, 39);
            this.SubmitBtn.TabIndex = 11;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseVisualStyleBackColor = true;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // MonthLbl
            // 
            this.MonthLbl.AutoSize = true;
            this.MonthLbl.Location = new System.Drawing.Point(26, 106);
            this.MonthLbl.Name = "MonthLbl";
            this.MonthLbl.Size = new System.Drawing.Size(47, 17);
            this.MonthLbl.TabIndex = 10;
            this.MonthLbl.Text = "Month";
            // 
            // InterestLbl
            // 
            this.InterestLbl.AutoSize = true;
            this.InterestLbl.Location = new System.Drawing.Point(26, 71);
            this.InterestLbl.Name = "InterestLbl";
            this.InterestLbl.Size = new System.Drawing.Size(55, 17);
            this.InterestLbl.TabIndex = 9;
            this.InterestLbl.Text = "Interest";
            // 
            // PrincipalLbl
            // 
            this.PrincipalLbl.AutoSize = true;
            this.PrincipalLbl.Location = new System.Drawing.Point(26, 32);
            this.PrincipalLbl.Name = "PrincipalLbl";
            this.PrincipalLbl.Size = new System.Drawing.Size(62, 17);
            this.PrincipalLbl.TabIndex = 8;
            this.PrincipalLbl.Text = "Principal";
            // 
            // MonthlyPaymentTextBox
            // 
            this.MonthlyPaymentTextBox.Location = new System.Drawing.Point(139, 243);
            this.MonthlyPaymentTextBox.Name = "MonthlyPaymentTextBox";
            this.MonthlyPaymentTextBox.Size = new System.Drawing.Size(100, 22);
            this.MonthlyPaymentTextBox.TabIndex = 42;
            // 
            // MonthlyPaymentLbl
            // 
            this.MonthlyPaymentLbl.AutoSize = true;
            this.MonthlyPaymentLbl.Location = new System.Drawing.Point(13, 243);
            this.MonthlyPaymentLbl.Name = "MonthlyPaymentLbl";
            this.MonthlyPaymentLbl.Size = new System.Drawing.Size(120, 17);
            this.MonthlyPaymentLbl.TabIndex = 41;
            this.MonthlyPaymentLbl.Text = "Monthly Payment:";
            // 
            // OutputDataGridView
            // 
            this.OutputDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OutputDataGridView.Location = new System.Drawing.Point(270, 12);
            this.OutputDataGridView.Name = "OutputDataGridView";
            this.OutputDataGridView.RowHeadersWidth = 51;
            this.OutputDataGridView.RowTemplate.Height = 24;
            this.OutputDataGridView.Size = new System.Drawing.Size(653, 499);
            this.OutputDataGridView.TabIndex = 43;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1056, 581);
            this.Controls.Add(this.OutputDataGridView);
            this.Controls.Add(this.MonthlyPaymentTextBox);
            this.Controls.Add(this.MonthlyPaymentLbl);
            this.Controls.Add(this.MonthTextBox);
            this.Controls.Add(this.InterestTextBox);
            this.Controls.Add(this.PrincipalTextBox);
            this.Controls.Add(this.SubmitBtn);
            this.Controls.Add(this.MonthLbl);
            this.Controls.Add(this.InterestLbl);
            this.Controls.Add(this.PrincipalLbl);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.OutputDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox MonthTextBox;
        private System.Windows.Forms.TextBox InterestTextBox;
        private System.Windows.Forms.TextBox PrincipalTextBox;
        private System.Windows.Forms.Button SubmitBtn;
        private System.Windows.Forms.Label MonthLbl;
        private System.Windows.Forms.Label InterestLbl;
        private System.Windows.Forms.Label PrincipalLbl;
        private System.Windows.Forms.TextBox MonthlyPaymentTextBox;
        private System.Windows.Forms.Label MonthlyPaymentLbl;
        private System.Windows.Forms.DataGridView OutputDataGridView;
    }
}


﻿//Program 0
//CIS 200-01
//Due: 9/9/2019
//Grading ID: M3326

using System;

namespace Program0
{
    public class Address
    {

        // Backing fields
        private string _name;        // Persons name
        private string _address1;    // Persons address line 1
        private string _address2;    // Persons address line 2
        private string _city;        // Persons city
        private string _state;       // Persons state
        private int _zip;            // Persons zip code

        // Magic values
        private readonly int lowerZip = 0;       // Mimimum value of a zip code
        private readonly int upperZip = 99999;   // Maximum value of a zip code

        //full address constructor
        // Precondition: Needs a name, address1, address2, city, state, zip.
        // Postcondition: The address is created with the specified values name, address1, address2, city, state, zip.
        public Address(string name, string address1, string address2, string city, string state, int zip)
        {
            // Use properties to ensure validation
            Name = name;
            Address1 = address1;
            Address2 = address2;
            City = city;
            State = state;
            Zip = zip;
        }

        //address constructor without the second address
        // Precondition: Needs a name, address1, city, state, zip.
        // Postcondition: The address is created with the specified values name, address1, city, state, zip.
        public Address(string name, string address1, string city, string state, int zip)
        {
            // Use properties to ensure validation
            Name = name;
            Address1 = address1;
            Address2 = "";
            City = city;
            State = state;
            Zip = zip;
        }

        //property for name, the string cant be empty
        public string Name
        {
            // Precondition: None
            // Postcondition: The addresses name has been returned
            get
            {
                return _name;
            }

            // Precondition: string IsNullOrWhiteSpace
            // Postcondition: The addresses name has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(Name)} can't be empty");
                }
                _name = value;
            }
        }
        public string Address1
        {
            // Precondition: None
            // Postcondition: The addresses address1 has been returned
            get
            {
                return _address1;
            }

            // Precondition: string IsNullOrWhiteSpace
            // Postcondition: The addresses address1 has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(Address1)} can't be empty");
                }
                _address1 = value;
            }
        }
        public string Address2
        {
            // Precondition: None
            // Postcondition: The addresses address2 has been returned
            get
            {
                return _address2;
            }

            // Precondition: None
            // Postcondition: The addresses address2 has been set to the specified value
            set
            {
                _address2 = value;
            }
        }
        public string City
        {
            // Precondition: None
            // Postcondition: The addresses city has been returned
            get
            {
                return _city;
            }

            // Precondition: string IsNullOrWhiteSpace
            // Postcondition: The addresses city has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(City)} can't be empty");
                }
                _city = value;
            }
        }
        public string State
        {
            // Precondition: None
            // Postcondition: The addresses state has been returned
            get
            {
                return _state;
            }

            // Precondition: string IsNullOrWhiteSpace
            // Postcondition: The addresses state has been set to the specified value
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(State)} can't be empty");
                }
                _state = value;
            }
        }
        public int Zip
        {
            // Precondition: None
            // Postcondition: The addresses zip has been returned
            get
            {
                return _zip;
            }

            // Precondition: value > 99999 || value < 0
            // Postcondition: The addresses zip has been set to the specified value
            set
            {
                if (value > upperZip || value < lowerZip)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(Zip)} must be between {lowerZip} - {upperZip}");
                }
                _zip = value;
            }
        }

        //override tostring and output all of the contents of the address
        // Precondition: None
        // Postcondition: A string with the address data is returned
        public override string ToString() =>
            $"{Name}\n" +
            $"{Address1}\n" +
            $"{(Address2 == String.Empty ? Address2 : Address2 + Environment.NewLine)}" +
            $"{City}, {State} {Zip:D5}\n";

    }
}

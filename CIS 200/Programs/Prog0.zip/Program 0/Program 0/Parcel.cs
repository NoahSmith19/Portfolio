﻿//Program 0
//CIS 200-01
//Due: 9/9/2019
//Grading ID: M3326

using System;
using System.Collections.Generic;
using System.Text;

namespace Program0
{
    //parcel is anything that can be shipped from one location to another
    public abstract class Parcel
    {
        // Precondition: Needs and originAddress and a destinationAddress
        // Postcondition: The parcel is created with the values given
        public Parcel(Address originAddress, Address destinationAddress)
        {
            OriginAddress = originAddress;
            DestinationAddress = destinationAddress;
        }

        //properties
        protected Address OriginAddress { get; set; }
        protected Address DestinationAddress { get; set; }


        //each instance of parcel calculates its cost differently
        public abstract decimal CalcCost();

        //override the tostring and print the origin and destination address
        public override string ToString() =>
            $"Origin:\n{OriginAddress}\n" +
            $"Destination:\n{DestinationAddress}\n" +
            $"Cost: {CalcCost()}\n\n";


    }
}

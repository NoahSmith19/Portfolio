﻿//Program 0
//CIS 200-01
//Due: 9/9/2019
//Grading ID: M3326

// File: Program.cs
// this file creates a test application that creates four addresses and
// letters and tests them
using System;
using System.Collections.Generic;
using System.Text;

namespace Program0
{
    class Program
    {
        // Precondition: None
        // Postcondition: The Address, Letter, and Parcel class has been tested.
        public static void Main(string[] args)
        {
            //create a list of parcels
            List<Parcel> parcels = new List<Parcel>();

            // Test data: 4 addresses to be used to sent letters to and from
            Address myHome = new Address("My Home", "417 Iowa Ave", "Louisville", "Kentucky", 40209);
            Address momsHome = new Address("Mom's Home", "11016 Broad Run Rd", "Louisville", "Kentucky", 40299);
            Address dadsHome = new Address("Dad's Home", "260 Kingswood Ct", "Taylorsville", "Kentucky", 40071);
            Address madisonsHome = new Address("Madison's Home", "10300 Vantage Rd", "Lousville", "Kentucky", 40299);

            //create a type of parcel, a letter, and set its origin, destination, and cost.
            Letter letterOne = new Letter(myHome, madisonsHome, .50M);
            parcels.Add(letterOne);
            Letter letterTwo = new Letter(dadsHome, myHome, .45M);
            parcels.Add(letterTwo);
            Letter letterThree = new Letter(madisonsHome, momsHome, .55M);
            parcels.Add(letterThree);

            //output the contents for each parcel
            parcels.ForEach(e =>
            {
                Console.WriteLine(e.ToString());
            });
        }
    }
}

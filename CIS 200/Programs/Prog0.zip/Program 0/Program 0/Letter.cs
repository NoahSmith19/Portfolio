﻿//Program 0
//CIS 200-01
//Due: 9/9/2019
//Grading ID: M3326

using System;
using System.Collections.Generic;
using System.Text;

namespace Program0
{
    //letter is a special type of parcel
    class Letter : Parcel
    {
        //fixed cost determined by the shippers
        private decimal _fixedCost;

        // Precondition: Needs and originAddress and a destinationAddress
        // Postcondition: The letter is created with the values given
        public Letter(Address originAddress, Address destinationAddress, decimal fixedCost)
            : base(originAddress, destinationAddress)
        {
            //a negative value will just be zero
            _fixedCost = fixedCost > 0 ? fixedCost : 0;
        }

        //letters have a fixed cost that will be returned
        public override decimal CalcCost()
        {
            return _fixedCost;
        }

        // Precondition: None
        // Postcondition: A string with the letters origin and destination address is returned
        public override string ToString() =>
            $"Origin:\n{OriginAddress}\n" +
            $"Destination:\n{DestinationAddress}\n" +
            $"Cost: {CalcCost()}\n\n";

    }
}

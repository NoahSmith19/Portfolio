﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: M3326

// File: TwoDayAirPackage.cs
// A special case of AirPackage

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    //Specifies two types of two day deliveries
    public enum DeliveryEnum
    {
        Early = 0,
        Saver = 1
    }

    public class TwoDayAirPackage : AirPackage
    {

        private decimal _saverDiscount = .15m; //The discount a saver gets

        //Constructor
        //Precondition: Needs origin, destination, and delivery type. Length, width, height and weight must be positive.
        //Postcondition: Creates TwoDayAirPackage
        public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight, DeliveryEnum deliveryType)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            DeliveryType = deliveryType;
        }

        //Precondition: None
        //Postcondition: Gets and sets DeliveryType.
        protected DeliveryEnum DeliveryType { get; set; }


        //Precondition: None
        //Postcondition: Returns the baseCost
        public override decimal CalcCost()
        {
            double scale = .20; //Scale used in equation

            decimal baseCost = (decimal)(scale * (Length + Width + Height) + scale * Weight);
            if (DeliveryType == DeliveryEnum.Saver)
                baseCost -= baseCost * _saverDiscount;
            return baseCost;
        }

        //Precondition: None
        //Postcondition: Returns a formatted string
        public override string ToString()
        {
            return base.ToString() + Environment.NewLine + $"Type of Delivery: {DeliveryType}";
        }
    }
}

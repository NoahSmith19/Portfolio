﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: M3326

// File: NextDayAirPackage.cs
// A special case of AirPackage

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class NextDayAirPackage : AirPackage
    {

        //fee set by the shipper
        private decimal _expressFee;

        //Constructor
        //Precondition: Origin, destination, length, width, height, and weight must be positive
        //Postcondition: Creates next day air package
        public NextDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight, decimal expressFee)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            ExpressFee = expressFee;
        }

        //Precondition: None
        //Postcondition: sets the express fee
        public decimal ExpressFee
        {
            get
            {
                return _expressFee;
            }
            private set
            {
                if (value >= 0)
                    _expressFee = value;
                else
                    throw new ArgumentOutOfRangeException("Express Fee can't be negative");
            }
        }

        //Precondition: None
        //Postcondition: Returns the cost
        public override decimal CalcCost()
        {
            double dimensionScale = .30; //Scale for the length, width, and height
            double weightScale = .25; //Scale for the weight

            decimal baseCost = (decimal)(dimensionScale * (Length + Width + Height) + weightScale * Weight) + ExpressFee;
            if (IsHeavy())
                baseCost += HeavyCharge(); //If heavy add the heavy charge
            if (IsLarge())
                baseCost += LargeCharge(); //If large add the large charge

            return baseCost;
        }

        //Precondition: None
        //Postcondition: Returns the charge for a heavy package
        protected decimal HeavyCharge()
        {
            double isHeavy = .20;  //weight ratio
            return (decimal)(Weight * isHeavy);
        }

        //Precondition: None
        //Postcondition: Returns the charge for a large package
        protected decimal LargeCharge()
        {
            double isLarge = .20; //large ratio
            return (decimal)((Length + Width + Height) * isLarge);
        }

        //Precondition: None
        //Postcondition: Returns a formatted string
        public override string ToString()
        {
            return base.ToString() + Environment.NewLine + $"Express Fee: {ExpressFee:C}\n";
        }
    }
}

﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: M3326

// File: Package.cs
// The Package class is an abstract class derived from Parcel

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Package : Parcel
    {
        //Backing fields
        private double _length; //Length of the package
        private double _width; //Width of the package
        private double _height; //Height of the package
        private double _weight; //Weight of the package

        //Constructor
        //Precondition: Must provide origin and destination address. Positive length, width, height, and weight.
        //Postcondition: Gets a package
        public Package(Address originAddress, Address destAddress, double length, double width, double height, double weight)
            : base(originAddress, destAddress)
        {
            Length = length;
            Width = width;
            Height = height;
            Weight = weight;
        }

        public double Length
        {
            //Precondition: None
            //Postcondition: Gets the packages length
            get
            {
                return _length;
            }
            //Precondition: Must be positive
            //Postcondition: Sets the packages Length or throws an exception.
            set
            {
                if (value > 0)
                    _length = value;
                else
                    throw new ArgumentOutOfRangeException("Length must be greater than zero");
            }
        }

        public double Width
        {
            //Precondition: None
            //Postcondition: Gets the packages width
            get
            {
                return _width;
            }
            //Precondition: Must be positive
            //Posrcondition: Sets the packages Width or throws an exception
            set
            {
                if (value > 0)
                    _width = value;
                else
                    throw new ArgumentOutOfRangeException("Width must be greater than zero");
            }
        }

        public double Height
        {
            //Precondition: None
            //Postcondition: Gets the packages height
            get
            {
                return _height;
            }
            //Precondition: Must be positive
            //Posrcondition: Sets the packages Height or throws an exception
            set
            {
                if (value > 0)
                    _height = value;
                else
                    throw new ArgumentOutOfRangeException("Height must be greater than zero");
            }
        }

        public double Weight
        {
            //Precondition: None
            //Postcondition: Gets the packages weight
            get
            {
                return _weight;
            }
            //Precondition: Must be positive
            //Posrcondition: Sets the packages Weight or throws an exception
            set
            {
                if (value > 0)
                    _weight = value;
                else
                    throw new ArgumentOutOfRangeException("Weight must be greater than zero");
            }
        }

        //Precondition: None
        //Posrcondition: Returns parcels to a string
        public override string ToString() =>
            base.ToString();
    }


}

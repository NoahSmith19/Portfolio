﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: M3326

// File: AirPackage.cs
// This is a special type of package with heavy and large status

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class AirPackage : Package
    {

        private int _heavyPackage = 50; //Anything greater is a heavy package
        private int _largePackage = 75; //Anything greater is a large package

        public AirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            //Uses the base constructor
        }

        //Precondition: None
        //Postcondition: Checks if package is at the heavy mark
        public bool IsHeavy()
        {
            return Weight >= _heavyPackage;
        }

        //Precondition: None
        //Postcondition: Checks if package is at the large mark
        public bool IsLarge()
        {
            return (Length + Width + Height) >= _largePackage;
        }

        //Precondition: None
        //Postcondition: Adds AirPackage and status to a string
        public override string ToString()
        {
            string isHeavy = IsHeavy() ? "Yes" : "No";
            string isLarge = IsLarge() ? "Yes" : "No";

            string s = base.ToString() + Environment.NewLine + 
                $"Heavy: {isHeavy} \n" +
                $"Large: {isLarge} \n";

            return s;
        }



    }
}

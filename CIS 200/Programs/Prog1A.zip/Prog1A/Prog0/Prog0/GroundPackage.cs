﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: M3326

// File: GroundPackage.cs
// This is a special type of package that calculates cost based on zip

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class GroundPackage : Package
    {

        //Constructor with base of package
        //Precondition: origin and destination are non negative length width and height
        //Postcondition: creates GroundPackage with zone distance
        public GroundPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight)
            : base(originAddress, destAddress, length, width, height, weight)
        {

        }

        public int ZoneDistance
        {
            //Precondition: None
            //Postcondition: Returns zone distance
            get
            {
                const int firstDigitFactor = 10000; //Used to extract first digit
                int diff = (OriginAddress.Zip / firstDigitFactor) - (OriginAddress.Zip / firstDigitFactor); //Calculates the zone distance

                return Math.Abs(diff); //Absolute value if negative
            }
        }

        //Precondition: None
        //Postcondition: Calculates the cost of shipment
        public override decimal CalcCost()
        {
            double sizeCostFactor = .25; //fraction for length width and height
            double weightCostFactor = .45; //fraction for zone distance plus zone scale
            int scale = 1; //how much zone distance is scaled

            return (decimal)(sizeCostFactor * (Length + Width + Height) + weightCostFactor * (ZoneDistance + scale) * Weight);
        }

        //Precondition: None
        //Postcondition: Formats the GroundPackage and Zone Distance to a string
        public override string ToString() =>
            base.ToString() + Environment.NewLine + $"Zone Distance: {ZoneDistance} \n";
    }
}

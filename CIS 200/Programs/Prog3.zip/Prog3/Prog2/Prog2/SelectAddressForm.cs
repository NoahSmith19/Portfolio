﻿// Program 3
// CIS 200-01
// Fall 2019
// Due: 11/11/2019
// By: M3326

// File: SelectAddressForm.cs
// The address selector, you give it a UPV that it will use to
// populate a select box that the user can edit.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UPVApp;

namespace Prog2
{
    public partial class SelectAddressForm : Form
    {
        //The UPV that is used with the form
        private UserParcelView UPV;

        //Precondition: Needs a UPV
        //Postcondition: Shows a Selection form
        public SelectAddressForm(UserParcelView upv)
        {
            InitializeComponent();

            //Set the UPV
            this.UPV = upv;

            //get the address names and set them to the select box items
            var addresses = UPV.AddressList.Select(s => s.Name).ToArray();
            AddressComboBox.Items.AddRange(addresses);
        }

        //Precondition: edit button clicked
        //Postcondition: shows the address form
        private void editButton_Click(object sender, EventArgs e)
        {
            //retrieves the index of the selected item
            var selectedIndex = AddressComboBox.SelectedIndex;

            //if nothing is selected display the following message
            if (selectedIndex < 0)
            {
                MessageBox.Show("An address must be selected to edit.");
                return;
            }

            //when the user selects a valid index the form is created
            AddressForm addressForm = new AddressForm();

            //gets the addresses
            var address = UPV.AddressAt(AddressComboBox.SelectedIndex);

            //the forms values are set based on the selected address
            addressForm.AddressName = address.Name;
            addressForm.Address1 = address.Address1;
            addressForm.Address2 = address.Address2;
            addressForm.City = address.City;
            addressForm.State = address.State;
            addressForm.ZipText = address.Zip.ToString();

            //hides the form
            this.Visible = false;

            //show the address form
            var result = addressForm.ShowDialog();

            //the user closed the form, if the edits were accepted set the values
            if (result == DialogResult.OK)
            {
                //sets the values from the form to the address
                address.Name = addressForm.AddressName;
                address.Address1 = addressForm.Address1;
                address.Address2 = addressForm.Address2;
                address.City = addressForm.City;
                address.State = addressForm.State;
                address.Zip = int.Parse(addressForm.ZipText);

                //close the form with ok
                this.DialogResult = DialogResult.OK;
            }
            else
            {
                //closes the form
                cancelButton_Click(sender, e);
            }
        }

        //Precondition: cancel button clicked
        //Postcondition: closes the form
        private void cancelButton_Click(object sender, EventArgs e)
        {
            //the form is closed
            this.DialogResult = DialogResult.Cancel;
        }
    }
}

﻿// Program 5
// CIS 200-01
// Fall 2019
// Due: 12/3/2019
// By: M3326

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BinaryTreeLibrary
{
    //Precondition: None
    //Postcondition: binary trees of different types created
    class Program
    {
        static void Main(string[] args)
        {
            //tree of ints
            Tree<int> i = new Tree<int>();

            i.InsertNode(1738);
            i.InsertNode(1776);
            i.InsertNode(2016);
            i.InsertNode(1999);
            i.InsertNode(1);
            i.InsertNode(2);
            i.InsertNode(3);
            i.InsertNode(7);
            i.InsertNode(21);
            i.InsertNode(420);

            //outputs the tree type and pauses
            Console.WriteLine("int tree");
            i.InorderTraversal();
            Console.WriteLine();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();


            //tree of doubles
            Tree<double> d = new Tree<double>();

            d.InsertNode(17.38);
            d.InsertNode(17.76);
            d.InsertNode(21.420);
            d.InsertNode(1.1);
            d.InsertNode(2.2);
            d.InsertNode(3.3);
            d.InsertNode(4.4);
            d.InsertNode(6.6);
            d.InsertNode(7.69);
            d.InsertNode(89.98);

            //outputs the tree type and pauses
            Console.WriteLine("double tree");
            d.InorderTraversal();
            Console.WriteLine();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();


            //tree of strings
            Tree<string> s = new Tree<string>();

            s.InsertNode("This");
            s.InsertNode("is");
            s.InsertNode("the");
            s.InsertNode("last");
            s.InsertNode("program");
            s.InsertNode("and");
            s.InsertNode("I");
            s.InsertNode("am");
            s.InsertNode("very");
            s.InsertNode("happy");

            //outputs the tree type and pauses
            Console.WriteLine("string tree");
            s.InorderTraversal();
            Console.WriteLine();
            Console.WriteLine("Press enter to continue...");
            Console.ReadLine();
            Console.Clear();

        }
    }
}

﻿// Program 1B
// CIS 200-01
// Fall 2019
// Due: 10/2/2019
// By: M3326

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Julie Cox", "11016 Broad Run Rd", "Louisville", "KY", 40299);
            Address a6 = new Address("Madison McNeil", "10300 Vantage Rd", "Gilbertsville", "KY", 42044);
            Address a7 = new Address("Noah Smith", "417 Iowa Ave", "Louisville", "KY", 40209);
            Address a8 = new Address("Kirt Smith", "260 Kingswood Ct", "Orange Park", "FL", 32003);



            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);

            List<Parcel> parcels = new List<Parcel>();      // List of test parcels

            parcels.Add(letter1); // Populate list
            parcels.Add(gp1);
            parcels.Add(ndap1);
            parcels.Add(tdap1);


            //Select all Parcels and order by destination zip (descending)
            WriteLine("Select all Parcels and order by destination zip (descending):");
            WriteLine("====================");
            var descDestination = from parcel in parcels orderby parcel.DestinationAddress.Zip descending select parcel;
            LogParcels(descDestination.ToList());

            //Select all Parcels and order by cost(ascending)
            WriteLine("Select all Parcels and order by cost(ascending):");
            WriteLine("====================");
            var ascCost = from parcel in parcels orderby parcel.CalcCost() select parcel;
            LogParcels(ascCost.ToList());

            //Select all Parcels and order by Parcel type(ascending) and then cost(descending)
            WriteLine("Select all Parcels and order by Parcel type(ascending) and then cost(descending):");
            WriteLine("====================");
            var ascTypeDescCost = from parcel in parcels orderby parcel.GetType().ToString() orderby parcel.CalcCost() descending select parcel;
            LogParcels(ascTypeDescCost.ToList());

            //Select all AirPackage objects that are heavy and order by weight(descending)
            WriteLine("Select all AirPackage objects that are heavy and order by weight(descending):");
            WriteLine("====================");
            var APHeavyWeightDesc = from airpackage in (from parcel in parcels
                                                        where parcel.GetType().Equals(typeof(NextDayAirPackage)) || parcel.GetType().Equals(typeof(AirPackage))
                                                        select (AirPackage)parcel)
                                    where airpackage.IsHeavy()
                                    orderby airpackage.Weight descending
                                    select airpackage;
            LogParcels(APHeavyWeightDesc.ToList());


            WriteLine("Original List:");
            WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();
       }

        // Precondition:  None
        // Postcondition: The LINQ statement specified outputs it's result as a string
        public static void LogParcels<T>(List<T> parcels)
        {
            parcels.ForEach(p =>
            {
                Type type = p.GetType();
                WriteLine("Type: " + p.ToString());
                WriteLine("====================");
            });
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}

﻿//Due: 11/25/19
//By: M3326

//File: ParcelTypeComparer.cs
// This contains a parcel comparer class that will sort a list of parcels
// by their destination zipcode

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    //Precondition: None
    //Postcondition: sorts parcels by their destination zipcode
    class ParcelZipComparer : IComparer<Parcel>
    {
        public int Compare(Parcel a, Parcel b)
        {
            //sets the zip and checks for null entries
            int? aZip = a?.DestinationAddress?.Zip;
            int? bZip = b?.DestinationAddress?.Zip;

            //If a is null move it up and if b is null nove it up, if both are, return 0.
            if(!aZip.HasValue || !bZip.HasValue)
            {
                return !aZip.HasValue ? (!bZip.HasValue ? 0 : 1) : -1;
            }
            //Decides if a or b is greater and moves accordingly
            else
            {
                return aZip.Value >= bZip.Value ? -1 : 1;
            }
        }
    }
}

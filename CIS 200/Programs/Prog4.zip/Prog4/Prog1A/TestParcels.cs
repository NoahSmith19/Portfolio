﻿// Program 1A
// CIS 200-01
// Fall 2019
// Due: 9/23/2019
// By: Andrew L. Wright (students use Grading ID)

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 79901); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 40202); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 84109); // Test Address 4
            Address a5 = new Address("My Mom", "11016 Broad Run Rd", "Apt. 7",
                "Louisville", "KY", 40299); // Test Address 5
            Address a6 = new Address("Lemonjello Bradley", "6555 Pau Place", "Apt. 420",
                "Portland", "ME", 24101); // Test Address 6
            Address a7 = new Address("John Hancock", "678 Pau Drive", "Apt. 96",
                "Louisville", "KY", 40071); // Test Address 7


            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 1, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a1, a4, 4, 12, 7, 13);        // Ground test object
            GroundPackage gp3 = new GroundPackage(a2, a2, 1, 3, 5, 12.5);        // Ground test object
            GroundPackage gp4 = new GroundPackage(a3, a1, 1.4, 10, 5, 12);        // Ground test object
            GroundPackage gp5 = new GroundPackage(a4, a1, 21, 12, 9, 21);        // Ground test object
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 49.5, 3.5, 8.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a4, a1, 146.5, 9.5, 2.0, // Two Day test object
                21.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a4, a1, 76.5, 21.5, 16.0, // Two Day test object
                130.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap4 = new TwoDayAirPackage(a4, a1, 96.5, 42.5, 28.0, // Two Day test object
                5.5, TwoDayAirPackage.Delivery.Saver);


            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list
            parcels.Add(gp1);     // Additional data has been added for testing
            parcels.Add(gp2);
            parcels.Add(gp3);
            parcels.Add(gp4);
            parcels.Add(gp5);
            parcels.Add(ndap1);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);
            parcels.Add(tdap4);

            //Display the original list
            WriteLine("Original List:");
            WriteLine("====================");
            foreach (Parcel p in parcels)  //Iterates through the parcels
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();

            //Display the list sorted by ascending cost
            WriteLine("Sorted by Ascending Cost:");
            parcels.Sort();   //Default Sort
            foreach (Parcel p in parcels)  //Iterates through the parcels
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();

            //Display the list sorted by descending destination zip
            WriteLine("Sorted by Descending Destination Zip:");
            parcels.Sort(new ParcelZipComparer());  //calls the comparer
            foreach (Parcel p in parcels)  //Iterates through the parcels
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();

            //Display the list by ascending parcel and descending cost
            WriteLine("Sorted by Ascending Parcel Type and then by Descending Cost:");
            parcels.Sort(new ParcelTypeComparer());  //calls the comparer
            foreach (Parcel p in parcels)  //Iterates through the parcels
            {
                WriteLine(p);
                WriteLine("====================");
            }
            Pause();
        }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            WriteLine("Press Enter to Continue...");
            ReadLine();

            Console.Clear(); // Clear screen
        }

    }
}

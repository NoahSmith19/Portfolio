﻿//Program 4
//CIS 200
//Fall 2019
//Due: 11/25/19
//By: M3326

//File: ParcelTypeComparer.cs
// This contains a parcel comparer class that will sort a list of parcels
// by their type and then their value

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    //Precondition: None
    //Postcondition: sorts parcels by their type and then cost
    class ParcelTypeComparer : IComparer<Parcel>
    {
        public int Compare(Parcel a, Parcel b)
        {
            //If a or b is null move them
            if (a == null || b == null)
            {
                return a == null ? (b == null ? 0 : 1) : -1;
            }

            //Get the type of each parcel for comparison
            Type aType = a.GetType();
            Type bType = b.GetType();

            //If the types dont match move one
            if (aType != bType)
            {
                //Select the lowest letter and move it
                return aType.ToString().ToLower()[0] > bType.ToString().ToLower()[0] ? 1 : -1;
            }
            else
            {
                //Use the default comparer
                return a.CompareTo(b);
            }
        }
    }
}

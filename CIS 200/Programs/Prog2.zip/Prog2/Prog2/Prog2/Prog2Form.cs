﻿// Program 2
// CIS 200-01
// Fall 2019
// Due: 10/21/2019
// Grading ID: M3326

using Prog2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        //UserParcelView helper class
        private UserParcelView UserParcelView;

        //Precondition: None
        //Postcondtion: Program created
        public Prog2Form()
        {
            InitializeComponent();

            //Create an instance of the class
            UserParcelView = new UserParcelView();

            //test data added to the form
            TestData();

            //outputs all of the data
            OutputData();
        }

        #region File

        //Precondition: None
        //Postcondition: Displays my information
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //NewLine shortcut
            var NL = Environment.NewLine;

            //Create a string of my information
            var about = "Program 2" + NL + "By: M3326" + NL + "CIS 200-01" + NL + "Fall 2019";

            //Show the string in a message box
            MessageBox.Show(about);
        }

        //Precondition: None
        //Postcondition: Program exits
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }

        #endregion

        #region Insert

        //Precondition: None
        //Postcondition: 
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Create the address form from the given UPV
            AddressForm addressForm = new AddressForm(UserParcelView);

            //Show the dialog
            addressForm.ShowDialog();

            OutputData(true);
        }

        //Precondition: None
        //Postcondition: 
        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Create the letter form from the given UPV
            LetterForm letterForm = new LetterForm(UserParcelView);

            //Show the dialog
            letterForm.ShowDialog();

            OutputData(true);
        }

        #endregion

        #region Report

        //Precondition: None
        //Postcondition: Outputs addresses to the text area
        private void listAddressesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Calls helper to output addresses
            OutputItems<Address>(UserParcelView.AddressList, "Addresses");
        }

        //Precondition: None
        //Postcondition: Outputs parcels to the text area
        private void listParcelsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //calls helper to output letters 
            OutputItems<Parcel>(UserParcelView.ParcelList, "Letters");
        }

        #endregion

        //Precondition: None
        //Postcondition: Outputs letters and addresses to the text area
        private void OutputData(bool clear = false)
        {
            //calls helper to print letters and doesnt clear already filled data
            OutputItems<Parcel>(UserParcelView.ParcelList, "Letters", clear);

            //Adds a new line for seperation
            outputTextArea.AppendText(Environment.NewLine);

            //calls helper to print addresses and doesnt clear already filled data
            OutputItems<Address>(UserParcelView.AddressList, "Addresses", false);

            //makes sure the scroll is at the top
            OutputScroll();
        }

        //Precondition: None
        //Postcondition: Scrolls to the top of the text area
        private void OutputScroll()
        {
            outputTextArea.SelectionStart = 0;
            outputTextArea.ScrollToCaret();
        }

        //Precondition: Have a list of items, a name, and if they go into the text area
        //Postcondition: Formats the outputs to the text area
        private void OutputItems<T>(List<T> items, string formattedType, bool clear = true)
        {
            //Clear before outputtng
            if (clear) outputTextArea.Clear();

            //Page header
            outputTextArea.AppendText("On File----------------");
            outputTextArea.AppendText(Environment.NewLine);

            //Helper used to print out the list, displays error if nothing to display
            FillOutput<T>(items, "No " + formattedType + " to display");

            //Scrolls to the top of the form
            OutputScroll();
        }

        //Precondition: List of items and an error message if empty
        //Postcondition: Adds an item to the output area
        private void FillOutput<T>(List<T> items, string error = "No items to display")
        {
            //If the list is empty display error message
            if(items == null || items.Count == 0)
            {
                outputTextArea.AppendText(error);
            }
            else
            {
                //loop to display items in order thet are entered
                for (var i = items.Count - 1; i > 0; i--)
                {
                    T item = items[i];

                    outputTextArea.AppendText(item.ToString());
                    outputTextArea.AppendText(Environment.NewLine);
                    outputTextArea.AppendText("-----------------------------");
                    outputTextArea.AppendText(Environment.NewLine);
                }
            }
        }

        //Precondition: None
        //Postcondition: Fills the form with data
        private void TestData()
        {
            //Adds test addresses
            UserParcelView.AddAddress("John Smith", "123 Any St.", "Apt. 45", "Louisville", "KY", 40202);
            UserParcelView.AddAddress("Julie Cox", "11016 Broad Run Rd", "Louisville", "KY", 40299);
            UserParcelView.AddAddress("Madison McNeil", "10300 Vantage Rd", "Gilbertsville", "KY", 42044);
            UserParcelView.AddAddress("Noah Smith", "417 Iowa Ave", "Louisville", "KY", 40209);
            UserParcelView.AddAddress("Kirt Smith", "260 Kingswood Ct", "Orange Park", "FL", 32003);
            UserParcelView.AddAddress("James Kirk", "654 Roddenberry Way", "Suite 321", "El Paso", "TX", 79901);

            //Adds test letters
            UserParcelView.AddLetter(UserParcelView.AddressAt(3), UserParcelView.AddressAt(0), 69.69m);
            UserParcelView.AddLetter(UserParcelView.AddressAt(0), UserParcelView.AddressAt(4), 420.20m);
            UserParcelView.AddLetter(UserParcelView.AddressAt(2), UserParcelView.AddressAt(5), 69.69m);
            UserParcelView.AddLetter(UserParcelView.AddressAt(5), UserParcelView.AddressAt(1), 69.69m);
            UserParcelView.AddLetter(UserParcelView.AddressAt(1), UserParcelView.AddressAt(3), 69.69m);
            UserParcelView.AddLetter(UserParcelView.AddressAt(1), UserParcelView.AddressAt(2), 69.69m);
        }

    }
}

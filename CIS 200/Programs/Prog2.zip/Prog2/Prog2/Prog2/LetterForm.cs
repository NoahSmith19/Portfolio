﻿// Program 2
// CIS 200-01
// Fall 2019
// Due: 10/21/2019
// Grading ID: M3326

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UPVApp;

namespace Prog2
{
    //Precondition: None
    //Postcondition: A form is created
    public partial class LetterForm : Form
    {
        //Precondition: None
        //Postcondition: A form is created
        private UserParcelView _UPV;

        //Precondition: Needs a UserParcelView
        //Postcondition: Creates the form
        public LetterForm(UserParcelView upv)
        {
            InitializeComponent();

            //Set the UserParcelView
            _UPV = upv;

            //Fill the combo boxes with the address names
            AddAddresses(_UPV.AddressList);
        }

        //Precondition: User clicked create
        //Postcondition: If valid close form
        private void createBtn_Click(object sender, EventArgs e)
        {
            //check if valid and if not errors will be returned
            if (!ValidateEntry()) return;

            //take the selected item and cast to AddressComboItem that is used to create a letter
            Address origin = (originBox.SelectedItem as AddressComboItem).Address;
            Address destination = (destinationBox.SelectedItem as AddressComboItem).Address;

            //used in parsing
            decimal fixedCost;

            //Try to parse the fixed cost
            bool parsed = decimal.TryParse(fixedCostInput.Text, out fixedCost);

            //if parse failed do the following
            if (!parsed)
            {
                //display a message and wait for a response
                DialogResult dialogResult = MessageBox.Show("An incorrect shipping value was entered.", "Is shipping free?", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    //Yes was selected, the shipping is free
                    fixedCost = 0;
                }
                else if (dialogResult == DialogResult.No)
                {
                    //No was selected, go back and try again
                    return;
                }
            }

            //Creates the letter with the UPV
            _UPV.AddLetter(origin, destination, fixedCost);

            //Closes the form
            this.Close();
        }

        //Precondition: User clicked cancel button
        //Postcondition: Closes the form
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        //Precondition: None
        //Postcondition: Allows someone to set items to the list
        public void AddAddresses(List<Address> addresses)
        {
            //Go through given addresses and convert to address combo items then convert to array for combo box
            var addressesArray = addresses.Select(add => new AddressComboItem(add)).ToArray();

            //Values for both origin and destination
            AddToComboBox(originBox, addressesArray);
            AddToComboBox(destinationBox, addressesArray);
        }

        //Precondition: Takes a filled combo box and an array of objects
        //Postcondition: Adds items to the combo box
        private void AddToComboBox(ComboBox box, object[] items)
        {
            box.Items.Clear();
            box.Items.AddRange(items);
        }

        //Precondition: None
        //Postcondition: Retuns a bool if not error labels will show
        private bool ValidateEntry()
        {
            //Checks if a user has selected an origin and destinations
            originErr.Visible = originBox.SelectedItem == null || originBox.SelectedItem.ToString() == "";
            destinationErr.Visible = destinationBox.SelectedItem == null || destinationBox.SelectedItem.ToString() == "";

            //If an error label is visible the form won't be valid
            return !(originErr.Visible || destinationErr.Visible);
        }

        //Precondition: Used in a combo box
        //Postcondition: Helper class to display the name in the combo box
        private class AddressComboItem
        {
            //Precondition: None
            //Postcondition: Constructs an AddressComboItem
            public AddressComboItem(Address address)
            {
                Address = address;
            }

            //Precondition: None
            //Postcondition: Sets the address for retrieval
            public Address Address { get; set; }

            //Precondition: None
            //Postcondition: Returns the text to be displayed
            public string DisplayText
            {
                get
                {
                    return Address.Name;
                }
            }

            //Precondition: None
            //Postcondition: Combo box calls to string to display text
            public override string ToString()
            {
                return DisplayText;
            }
        }
    }
}

﻿// Program 2
// CIS 200-01
// Fall 2019
// Due: 10/21/2019
// Grading ID: M3326

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UPVApp;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        //Handles addresses and parcels
        private UserParcelView _UPV;

        //Precondition: Needs a UserParcelView
        //Postcondition: Creates the form
        public AddressForm(UserParcelView upv)
        {
            InitializeComponent();

            //Set the UserParcelView
            _UPV = upv;

            //Fill the states box with some states
            AddStates();
        }

        //Precondition: Statebox must exist
        //Postcondition: Adds states to the statebox
        private void AddStates()
        {
            //Add states to the statebox's items
            stateBox.Items.Add("KY");
            stateBox.Items.Add("TN");
            stateBox.Items.Add("IL");
            stateBox.Items.Add("IN");
            stateBox.Items.Add("MO");
            stateBox.Items.Add("CA");
            stateBox.Items.Add("FL");
        }

        //Precondition: None
        //Postcondition: Checks each input for validation and returns the invalid ones
        private bool ValidateEntry()
        {

            //IF any of the following don't match requirements throw up the error
            firstErr.Visible = firstInput.Text == "" && lastInput.Text == "";
            lastErr.Visible = firstErr.Visible;
            line1Err.Visible = addressLine1Input.Text == "";
            cityErr.Visible = cityInput.Text == "";
            stateErr.Visible = stateBox.SelectedItem == null || stateBox.SelectedItem.ToString() == "";

            //Validate zip, used in parsing
            int zip;
            bool parsed = int.TryParse(zipInput.Text, out zip);

            //If zip outside of bounds or parse failed throw up the error
            zipErr.Visible = !parsed || zip < Address.MIN_ZIP || zip > Address.MAX_ZIP;

            //If any of the star labels are showing the form is invalid
            return !(firstErr.Visible || line1Err.Visible || cityErr.Visible || stateErr.Visible || zipErr.Visible);
        }

        //Precondition: User clicked create
        //Postcondition: If the form isn't valid errors are shown
        private void createBtn_Click(object sender, EventArgs e)
        {
            //Checks if the form is valid
            if (!ValidateEntry())
            {
                return;
            }

            //sets the validated inputs into variables
            string name = firstInput.Text + " " + lastInput.Text;
            string addressLine1 = addressLine1Input.Text;
            string addressLine2 = addressLine2Input.Text;
            string city = cityInput.Text;
            string state = stateBox.SelectedItem.ToString();
            int zip = int.Parse(zipInput.Text);

            //Adds the address to the UPV
            _UPV.AddAddress(name, addressLine1, addressLine2, city, state, zip);

            //Closes the form
            this.Close();
        }

        //Precondition: User clicled cancel
        //Postcondition: The address form is closed
        private void cancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
